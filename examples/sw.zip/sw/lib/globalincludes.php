<!-- 
<script type="text/javascript" src="/js/jquery/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="/js/jquery/jquery-ui-1.8.9.custom.min.js"></script>
-->
<script type="text/javascript" src="/js/jquery/beagle_jquery.js"></script>
<!-- 
<script type="text/javascript" src="/js/jquery/mask/jquery.loadmask.min.js"></script>
<script type="text/javascript" src="/js/jquery/SimplejQueryDropdowns/js/jquery.dropdownPlain.js"></script>
-->
 
<script type="text/javascript" src="/js/jquery/jquery.fancybox-1.3.4/fancybox/jquery.fancybox-1.3.4.js"></script>

<link rel="stylesheet" href="/js/jquery/jquery.fancybox-1.3.4/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
<script type="text/javascript" src="/js/beaglejs/beagleclasses.js"></script>
<script type="text/javascript" src="/js/login.js"></script>


<script type="text/javascript" src="/js/core.js"></script>
<!--  <script type="text/javascript" src="/js/htmlmaker.js"></script> -->
<script type="text/javascript" src="/js/beaglejs/beagle_extentions/form_validate.js"></script>



<script type="text/javascript">
var resetTab = function()
{
	$.ajax({
			url:"/ajax/global_ajax.php",
			data:{id:'resettab'},
			async:false,
			dataType:'html',
			beforeSend:function() { timer.startWait(); },
			success:function()
			{
				window.location.href = window.location.href;
			}
	});
	
}
document.onkeydown = function (e) 
{
	var evt = false;
	if(e == undefined)
	{ 
		
		key = window.event.keyCode; 
		if(window.event.ctrlKey)
		{
			
			var evt = true;
		}
	}
	else
	{
		key = e.which;
		var evt = e.ctrlKey; 
	}

	var ctrl = false;
	if(evt == true)
	{
		if (key === 116) 
		{
		    resetTab();
		}
	}
	
	
	
};


</script>
