<?php
function dbNow()
{
	return mkToTimeStamp(time());
}

/**
 * mkToTimeStamp is used for making epoch time into postGres timestamp
 * @param $date (ephoch format)
 * @return integer or false
 * @author Jason Ball
 */
function mkToTimeStamp($date)
{
	if($date != "" && is_numeric($date))
	{
		$datetime = date("Y-m-d H:i:s",$date);
		return $datetime;
	}
	else
	{
		 return ""; 
	}
		
}

/**
 * 
 * This function will log any data interaction
 * @param string $table
 * @param integer $key
 * @param array or serialize string $pre
 * @param array or serialize string $post
 * @return void
 * @author Jason Ball
 * @copyright 08/20/2011
 */
function dbLogSave($table,$key,$action,$pre,$post)
{
	$U = restoreClass('userclass');
	if($U !== false)
	{
		$ip = $_SERVER['REMOTE_ADDR'];
		
		if(is_array($pre))
		{
			$tpre = serialize($pre);
			$pre = $tpre;
		}
		if(is_array($post))
		{
			$tpost = serialize($post);
			$post = $tpost;
		}
		
		global $DB;
		$SQL = "insert into edit_log (user_id,ip,edit_log.table,edit_log.key,presave,postsave,edit_log.action)
		values ('".$U->getUserId()."','".$ip."','".$DB->escape($table)."','".$DB->escape($key)."','".$DB->escape($pre)."','".$DB->escape($post)."','".$DB->escape($action)."');";
		$DB->query($SQL);
	} 
}