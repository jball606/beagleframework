<?php
class utilities_states_controller extends beagleResultClass
{
	public function __construct()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	public function __wakeup()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	protected function cleanName($name)
	{
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from utilities_states 
					 inner join state 
					 	on utilities_states.state = state.abv";	
		
		return $this->executSearch(array('first'=>$first,
											'limit'=>$limit,
											'excel'=>$excel,
											'SQL_F'=>$SQL_F,
											'key'=>array('id'=>'utilities_states.utility_state_id','name'=>'utilities_states.utility_state_id','sqlkey'=>'utility_state_id'),
											'all'=>$all,
											'printsql'=>false));
		
	}
	/*
	public function loadSubWhere($where)
	{
		$array['utilities_states']['name'] = $where;
		$this->loadLetterNav($array);
	}
		*/
	
	public function showResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		$this->viewitems['state.name'] = 'state.name';
		//$this->viewitems['utilities_states.key'] = 'utilities_states.key';
		//$this->viewitems['utilities_states.end_date'] = 'utilities_states.end_date';
		
		return $this->runResultPage(array('first'=>false,
											'limit'=>false,
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											'edit_pencil'=>array('key'=>'utility_state_id'),
											'lib'=>$args['lib'],
											'showperpage'=>false,
											'showcount'=>false,
											'showemptyresult'=>true,
											'sel'=>array('name'=>'utilitystatedel','key'=>'utility_state_id'),
											'bottommenu' => getView('utilitystatebottom.php','utility'),
											//'lettermenu'=>array('col'=>'[utilities_states][name]','name'=>'Utility Name','key'=>'name'),
										 								
		));
		
		
		
	}
	
	
	
}
?>