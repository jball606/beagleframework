<?php
class utility_tariffs_controller extends beagleResultClass
{
	public function __construct()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
		
		$list = new sslistclass('V2DB');
		
		$this->editclass['tariff_id'] = new beagleResultEditHtmlClass(array(
																				'table'=>'utility_tariffs',
																				'field'=>'tariff_id',
																				'htmltype'=>4,
																				'listvalues'=>$list->tariffs("","A"),
																			));
		
		$this->editclass['utility_default'] = new beagleResultEditHtmlClass(array(
																			'table'=>'utility_tariffs',
																			'field'=>'default',
																			'htmltype'=>3,
																			'check'=>1,
																				
																			));
																			
		$this->editclass['preferred_solar'] = new beagleResultEditHtmlClass(array(
																					'table'=>'utility_tariffs',
																					'field'=>'preferred_solar',
																					'htmltype'=>3,
																					'check'=>1,
		
																				
																			));
	}
	
	public function __wakeup()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	protected function cleanName($name)
	{
		if($name == "tariffs.tariff_id")
		{
			return "Tariff";
		}
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from utility_tariffs 
					 inner join tariffs 
					 	on utility_tariffs.tariff_id = tariffs.tariff_id
					 inner join utilities_states
					 	on utility_tariffs.utility_state_id = utilities_states.utility_state_id ";	
		
		return $this->executSearch(array('first'=>$first,
											'limit'=>$limit,
											'excel'=>$excel,
											'SQL_F'=>$SQL_F,
											'key'=>array('id'=>'utility_tariffs.id','name'=>'utility_tariffs.id','sqlkey'=>'id'),
											'all'=>$all,
											'printsql'=>false));
		
	}
	/*
	public function loadSubWhere($where)
	{
		$array['utilities_states']['name'] = $where;
		$this->loadLetterNav($array);
	}
		*/
	public function showResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		$this->viewitems['tariffs.tariff_id'] = "";
		$this->viewitems['utility_tariffs.default'] = "case when utility_tariffs.default = 1 then 1 else '' end as utility_default";
		$this->viewitems['utility_tariffs.preferred_solar'] = "case when utility_tariffs.preferred_solar = 1 then 1 else '' end as preferred_solar";
		//$this->viewitems['utilities_states.key'] = 'utilities_states.key';
		//$this->viewitems['utilities_states.end_date'] = 'utilities_states.end_date';
		
		return $this->runResultPage(array('first'=>$args['first'],
											'limit'=>$args['limit'],
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											//'link'=>array('field'=>'client_name','key'=>'client_id'),
			//								'dates'=>array('start_date'=>"m/d/Y", 'end_date'=>'m/d/Y'),
											'lib'=>$args['lib'],
											'showperpage'=>false,
											'sel'=>array('name'=>'utilitytariffdel','key'=>'id'),
											'showcount'=>false,
											'showemptyresult'=>true,
											'all'=>true,
											'edit'=>'id',
											'bottommenu' => getView('utilitytariffbottom.php','utility'),
											'hiddenrows'=>array('id'),
		
										 								
		));
		
		
		
	}
	
	
	
}
?>