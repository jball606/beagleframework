<?php
class utility_multipliers_controller extends beagleResultClass
{
	
	public function __construct()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);

		$list = new sslistclass('V2DB');
		
		$this->editclass['multiplier'] = new beagleResultEditHtmlClass(array(
																				'table'=>'utility_multipliers',
																				'field'=>'multiplier',
																				'htmltype'=>1,
																				'size'=>25,
																			));
		
		$this->editclass['lease_term'] = new beagleResultEditHtmlClass(array(
																				'table'=>'utility_multipliers',
																				'field'=>'lease_term',
																				'htmltype'=>1,
																				'size'=>5,
																			));
																			
		$this->editclass['multiplier_type_id'] = new beagleResultEditHtmlClass(array(
																				'table'=>'utility_multipliers',
																				'field'=>'multiplier_type_id',
																				'htmltype'=>4,
																				'listvalues'=>$list->multiplierTypes("","A"),
																			));
	}
	
	public function __wakeup()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	protected function cleanName($name)
	{
		if($name == "multiplier_types.multiplier_type_id")
		{
			return "Multiplier Type";
		}
		
		if($name == "utility_providers.name")
		{
			return "Utility Provider";
		}
		
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from utility_multipliers 
					 inner join multiplier_types
					 	on utility_multipliers.multiplier_type_id = multiplier_types.multiplier_type_id
					 inner join utilities_states
					 	on utility_multipliers.utility_state_id = utilities_states.utility_state_id 
					 inner join utility_providers
					 	on utilities_states.utility_id = utility_providers.utility_id";	
		
		return $this->executSearch(array('first'=>$first,
											'limit'=>$limit,
											'excel'=>$excel,
											'SQL_F'=>$SQL_F,
											'key'=>array('id'=>'utility_multipliers.utility_multiplier_id','name'=>'utility_multipliers.utility_multiplier_id','sqlkey'=>'utility_multiplier_id'),
											'all'=>$all,
											'printsql'=>false));
		
	}
	
	public function loadSubWhere($where)
	{
		$array['utility_providers']['name'] = $where;
		$this->loadLetterNav($array);
	}
		
	public function removeUtilityMultipliers($args)
	{
		if(isPopArray($args))
		{
			$UM = new utility_multipliers();
			foreach($args as $k)
			{
				$UM->delete(array('utility_multiplier_id'=>$k));
			}	
		}
		
	}
	
	public function showAddMultiplier()
	{
		return $this->showTemplate(getView('popups/addfullmultiplier.php','utility'),$this);	
		
	}
	
	/**
	 * This mehtod will create a new multiplier using a full utility data
	 *
	 * @param array $in_args
	 * <pre>
	 * utility => 	utility_id
	 * 				state
	 * multiplier =>	multiplier_type_id
	 * 					lease_term
	 * 					multiplier
	 * </pre>
	 * @return mixed integer or Error
	 * @author Jason Ball
	 * @copyright 08/28/2011	
	 */
	public function addNewMultlipleir($in_args)
	{
		$args = defaultArgs($in_args, array('utility'=>array(),
											'multiplier'=>array(),
										));
										
		
		$US = new utilities_states();
		$usid = $US->getOne(array('utility_id'=>$args['utility']['utility_id'],'lower(state)'=>strtolower($args['utility']['state'])),array('fields'=>array('utility_state_id')));
		if(!isSetNum($usid['utility_state_id']))
		{
			$usid = $US->add(array('utility_id'=>$args['utility']['utility_id'],'state'=>strtoupper($args['utility']['state'])));	
			
		}
		else 
		{
			$tmp = $usid['utility_state_id'];
			$usid = $tmp;
		}
		
		$v = $args['multiplier'];
		$v['utility_state_id'] = $usid;
		
		$UM = new utility_multipliers();
		$umid = $UM->addOrUpdate(array('utility_state_id'=>$usid,'lease_term'=>$args['multiplier']['lease_term'],'multiplier_type_id'=>$in_args['multiplier']['multiplier_type_id']), $v);
		
		if(!is_numeric($umid))
		{
			return $UM->error;
		}
		
		return $umid;
		
			
		
	}
	
	private function showFullResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));

		$this->viewitems['utility_providers.name'] = "";
		$this->viewitems['utilities_states.state'] = "";
		$this->viewitems['multiplier_types.multiplier_type_id'] = "";
		$this->viewitems['utility_multipliers.lease_term'] = "";
		$this->viewitems['utility_multipliers.multiplier'] = "";
		
		return $this->runResultPage(array('first'=>$args['first'],
											'limit'=>$args['limit'],
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											//'edit_pencil'=>array('key'=>'utility_multiplier_id'),
											'lib'=>$args['lib'],
											//'showperpage'=>false,
											//'showcount'=>false,
											'showemptyresult'=>true,
											'sel'=>array('name'=>'utilitymultdel','key'=>'utility_multiplier_id'),
											'bottommenu' => getView('fullutilitymultiplierbottom.php','utility'),
											'all'=>true,
											'edit'=>'utility_multiplier_id',
											'hiddenrows'=>array('utility_multiplier_id'),
											'lettermenu'=>array('col'=>'[utility_providers][name]','name'=>'Utility Name','key'=>'name'),
						
										 								
		));
		
		
		
	}
	
	private function showUtilityResultPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		$this->viewitems['multiplier_types.multiplier_type_id'] = "";
		$this->viewitems['utility_multipliers.lease_term'] = "";
		$this->viewitems['utility_multipliers.multiplier'] = "";
		//$this->viewitems['utility_multipliers.utility_multiplier_id'] = "";
		//$this->viewitems['utilities_states.key'] = 'utilities_states.key';
		//$this->viewitems['utilities_states.end_date'] = 'utilities_states.end_date';
		
		return $this->runResultPage(array('first'=>$args['first'],
											'limit'=>$args['limit'],
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											//'edit_pencil'=>array('key'=>'utility_multiplier_id'),
											'lib'=>$args['lib'],
											'showperpage'=>false,
											'showcount'=>false,
											'showemptyresult'=>true,
											'sel'=>array('name'=>'utilitymultdel','key'=>'utility_multiplier_id'),
											'bottommenu' => getView('utilitymultiplierbottom.php','utility'),
											'all'=>true,
											'edit'=>'utility_multiplier_id',
											'hiddenrows'=>array('utility_multiplier_id'),
						
										 								
		));
		
	}
	
	public function showResultsPage($in_args = array())
	{
		if(isset($in_args['lib']))
		{
			switch ($in_args['lib'])
			{
				case "utilitymultiplierfullsearch":
					return $this->showFullResultsPage($in_args);
					break;
				case "utilitymultipliersearch":
					return $this->showUtilityResultPage($in_args);
					break;
			
			}
		}
	}
	
	
	
}
?>