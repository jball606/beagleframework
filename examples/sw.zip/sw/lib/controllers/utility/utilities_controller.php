<?php
class utilities_controller extends beagleResultClass
{
	public function __construct()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	public function __wakeup()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	protected function cleanName($name)
	{
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from utility_providers ";	
		
		return $this->executSearch(array('first'=>$first,
											'limit'=>$limit,
											'excel'=>$excel,
											'SQL_F'=>$SQL_F,
											'key'=>array('id'=>'utility_providers.utility_id','name'=>'utility_providers.utility_id','sqlkey'=>'utility_id'),
											'all'=>$all,
											'printsql'=>false));
		
	}
	
	public function loadSubWhere($where)
	{
		$array['utility_providers']['name'] = $where;
		$this->loadLetterNav($array);
	}
		
	public function showResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		$this->viewitems['utility_providers.name'] = 'utility_providers.name';
		$this->viewitems['utility_providers.key'] = 'utility_providers.key';
		//$this->viewitems['utility_providers.end_date'] = 'utility_providers.end_date';
		
		return $this->runResultPage(array('first'=>$args['first'],
											'limit'=>$args['limit'],
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											//'link'=>array('field'=>'client_name','key'=>'client_id'),
			//								'dates'=>array('start_date'=>"m/d/Y", 'end_date'=>'m/d/Y'),
											'edit_pencil'=>array('key'=>'utility_id'),
											'lib'=>$args['lib'],
											'lettermenu'=>array('col'=>'[utility_providers][name]','name'=>'Utility Name','key'=>'name'),
										 								
		));
		
		
		
	}
	
}
?>