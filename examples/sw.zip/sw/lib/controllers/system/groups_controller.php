<?php
class groups_controller extends beagleResultClass
{
	
	protected function cleanName($name)
	{
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from groups ";	
		
		return $this->executSearch(array('first'=>$first,
											'limit'=>$limit,
											'excel'=>$excel,
											'SQL_F'=>$SQL_F,
											'key'=>array('id'=>'groups.group_id','name'=>'groups.group_id','sqlkey'=>'group_id'),
											'all'=>$all,
											'printsql'=>false));
		
	}
	
	public function loadSubWhere($where)
	{
		$array['groups']['group_name'] = $where;
		$this->loadLetterNav($array);
	}
		
	public function showResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		$this->viewitems['groups.group_name'] = 'groups.group_name';
		$this->viewitems['groups.start_date'] = 'groups.start_date';
		$this->viewitems['groups.end_date'] = 'groups.end_date';
		
		return $this->runResultPage(array('first'=>$args['first'],
											'limit'=>$args['limit'],
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											//'link'=>array('field'=>'client_name','key'=>'client_id'),
											'dates'=>array('start_date'=>"m/d/Y", 'end_date'=>'m/d/Y'),
											'edit_pencil'=>array('key'=>'group_id'),
											'lib'=>$args['lib'],
											'lettermenu'=>array('col'=>'[groups][group_name]','name'=>'Group Name','key'=>'group_name'),
										 								
		));
		
		
		
	}
	
}
?>