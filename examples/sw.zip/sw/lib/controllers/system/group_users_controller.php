<?php
class group_users_controller extends beagleresultclass
{
	public $driver = "user";
	
	protected function cleanName($name)
	{
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from groups 
					left join group_users
						on groups.group_id = group_users.group_id
					left join users
						on group_users.user_id = users.user_id 
					left join group_user_type
						on group_users.group_user_type_id = group_user_type.group_user_type_id ";	
		
		$search_array = array(
								'first'=>$first,
								'limit'=>$limit,
								'excel'=>$excel,
								'SQL_F'=>$SQL_F,
								'all'=>$all,
								'printsql'=>false
							);
		
		if($this->driver == "user")
		{
			$search_array['key'] = array('id'=>'groups.group_id','name'=>'groups.group_id','sqlkey'=>'group_id');
		}
		else 
		{
			$search_array['key'] = array('id'=>'users.user_id','name'=>'users.user_id','sqlkey'=>'user_id');
		}
		
		return $this->executSearch($search_array);
		
	}
	
	public function setWhere($in_args)
	{
		if(isPopArray($in_args))
		{
			$this->whereitems = $in_args;
		}	
		
	}
	
	public function showResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		
		$resultarray = array(
								'first'=>false,
								'limit'=>false,
								'orderby'=>$args['orderby'],
								'orderdir'=>$args['orderdir'],
								//'link'=>array('field'=>'client_name','key'=>'client_id'),
								'dates'=>array('start_date'=>"m/d/Y", 'end_date'=>'m/d/Y'),
								'showperpage'=>false,
								'showcount'=>false,
								'showemptyresult'=>true,
								'sel'=>array('name'=>'groupuserdel','key'=>'user_id'),
								'lib'=>$args['lib'],
								'allowsort'=>false,	
								'hiddenrows'=>array('user_id'),							
							);
		
		
		if($this->driver == 'user')
		{
			$this->viewitems['groups.group_name'] = 'groups.group_name';
			$this->viewitems['groups.start_date'] = 'groups.start_date';
			$this->viewitems['groups.end_date'] = 'groups.end_date';
		}
		else 
		{
			$resultarray['orderdir'] = array();
			$resultarray['orderby'] = array();
			
			$this->viewitems['users.first_name'] = 'users.first_name';
			$this->viewitems['users.last_name'] = 'users.last_name';
			$this->viewitems['group_user_type.group_user_type'] = 'group_user_type.group_user_type';
			//$resultarray['edit_pencil'] = array('key'=>'user_id');
			$resultarray['orderby'][] = 'group_user_type.group_user_type_id';
			$resultarray['orderby'][] = 'users.first_name';
			$resultarray['orderdir'][] = 1;
			$resultarray['orderdir'][] = 1;
			$resultarray['bottommenu'] = getView('groupmembersbottom.php','systemadmin');
			//$resultarray['lettermenu'] = array('col'=>'[users][first_name]','name'=>'Group Name','key'=>'group_name'
		}
		
		
		return $this->runResultPage($resultarray);
		
		
		
	}
	
}
?>