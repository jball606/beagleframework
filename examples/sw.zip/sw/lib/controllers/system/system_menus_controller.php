<?php
class system_menus_controller extends beagleResultclass
{
	
	protected function cleanName($name)
	{
		if($name == "sm.menu_name")
		{
			return "parent";
		}
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from system_menus 
					left join system_menus sm
						on system_menus.parent = sm.menu_id ";	
		
		return $this->executSearch(array('first'=>$first,
											'limit'=>$limit,
											'excel'=>$excel,
											'SQL_F'=>$SQL_F,
											'key'=>array('id'=>'system_menus.menu_id','name'=>'system_menus.menu_id','sqlkey'=>'menu_id'),
											'all'=>$all,
											'printsql'=>false));
		
	}
	
	public function loadSubWhere($where)
	{
		$array['system_menus']['menu_name'] = $where;
		$this->loadLetterNav($array);
	}
		
	public function showResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		$this->viewitems['system_menus.menu_name'] = 'system_menus.menu_name';
		$this->viewitems['system_menus.link'] = 'system_menus.link';
		$this->viewitems['sm.menu_name'] = 'sm.menu_name as parent';
		
		return $this->runResultPage(array('first'=>$args['first'],
											'limit'=>$args['limit'],
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											//'link'=>array('field'=>'client_name','key'=>'client_id'),
											//'dates'=>array('start_date'=>"m/d/Y", 'end_date'=>'m/d/Y'),
											'edit_pencil'=>array('key'=>'menu_id'),
											'lib'=>$args['lib'],
											'lettermenu'=>array('col'=>'[system_menus][menu_name]','name'=>'Menu Name','key'=>'system_menus.menu_name'),
										 								
		));
		
		
		
	}
	
}
?>