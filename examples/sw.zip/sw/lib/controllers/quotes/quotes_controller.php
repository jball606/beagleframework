<?php
class quotes_controller extends beagleResultClass
{
	public function __construct()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	public function __wakeup()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	protected function cleanName($name)
	{
		return $this->standardTitle($name);
	}
	
	protected function run_Search($first=0,$limit=20,$excel=false,$all=false)
	{
		$SQL_F = " from quotes
					inner join users as customer 
					on quotes.user_id = customer.id
					left join quote_statuses 
					on quotes.quote_status_id = quote_statuses.id  
					";	
		
	//	$this->whereitems['quotes']['user_id'] = 'null';
	//	$this->whereitems['quotes']['user_id'] = "!null";
	//	$this->whereitems['customer']['first_name'] = "!null";
		
		return $this->executSearch(array('first'=>$first,
											'limit'=>$limit,
											'excel'=>$excel,
											'SQL_F'=>$SQL_F,
											'key'=>array('id'=>'quotes.id','name'=>'quotes.id','sqlkey'=>'id'),
											'all'=>$all,
											'printsql'=>false));
		
	}
	
	public function loadSubWhere($where)
	{
		$array['quotes']['site_state'] = $where;
		$this->loadLetterNav($array);
	}
		
	public function showResultsPage($in_args = array())
	{
		$args = defaultArgs($in_args,array('first'=>false,
											'limit'=>false,
											'orderby'=>false,
											'orderdir'=>false,
											'lib'=>'search',
										));
		
		$this->viewitems['customer.first_name'] = 'customer.first_name';
		$this->viewitems['customer.email'] = 'customer.email';
		$this->viewitems['quotes.site_address'] = 'quotes.site_address';
		$this->viewitems['quotes.site_state'] = 'quotes.site_state';
		$this->viewitems['quote_statuses.title'] = 'quote_statuses.title';
		$this->viewitems['quotes.created'] = 'quotes.created';
		
		return $this->runResultPage(array('first'=>$args['first'],
											'limit'=>$args['limit'],
											'orderby'=>$args['orderby'],
											'orderdir'=>$args['orderdir'],
											//'link'=>array('field'=>'client_name','key'=>'client_id'),
											'dates'=>array('created'=>"m/d/Y"),
											'edit_pencil'=>array('key'=>'id'),
											'lib'=>$args['lib'],
											'lettermenu'=>array('col'=>'[quotes][site_state]','name'=>'Site State','key'=>'site_state'),
										 								
		));
		
		
		
	}
	
}
?>