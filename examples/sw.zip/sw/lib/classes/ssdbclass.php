<?php
class ssdbclass extends beagleDbClass
{
	protected function dataLog($keys,$values,$action="add")
	{
		$id = '';
		$pre = array();
		if(isset($keys[$this->pkey]))
		{
			$id = $keys[$this->pkey];
			$pre = $this->getOne(array($this->pkey=>$id));
			if(!isPopArray($pre))
			{
				$pre = "No previous Data";
			}
			
		} 
		
		dbLogSave($this->table, $id, $action, $pre, $values);
	}
	
	
}