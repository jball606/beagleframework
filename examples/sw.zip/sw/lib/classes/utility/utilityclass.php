<?php
/**
 * This is the class for utility data
 * @package Solar Services
 * @subpackage Classes
 * 
 * @author Jason Ball
 * @copyright 08/19/2011
 */
class utilityclass extends ssbaseclass
{
	private $utilitydata = array();
	private $utility_id = false;
	public $currentstate = false;
	
	public function __construct($in_args = array())
	{
		$args = defaultArgs($in_args,array('utility_id'=>false));
		
		global $V2DB;
		$this->loadSystemDB($V2DB);
		$this->getInternalUser();
		
		if(is_numeric($args['utility_id']))
		{
			$this->loadUtility($args['utility_id']);
		}
		
	}
	
	public function __wakeup()
	{
		global $V2DB;
		$this->loadSystemDB($V2DB);	
	}
	
	public function addUtilityMultiplier($in_args)
	{
		$args = defaultArgs($in_args,array(
											'lease_term'=>'',
											'multiplier_type_id'=>'',
											'multiplier'=>''
							));

							
		if(is_numeric($this->currentstate) && is_numeric($this->utility_id))
		{
			$UM = new utility_multipliers();
			$args['utility_state_id'] = $this->currentstate;
			
			$value = $UM->add($args);	

			if(!is_numeric($value))
			{
				return $UM->error;
			}
			
			return $value;
			
		}
		
	}
	
	private function loadUtility($utility_id)
	{
		if(is_numeric($utility_id))
		{
			$UP = new utility_providers();
			$row = $UP->getOne(array('utility_id'=>$utility_id));
			$this->utilitydata = $row;
			$this->utility_id = $utility_id;
			$this->loadUtilityStates();
			
			$ULD = new utility_lease_defaults();
			$tmp = $ULD->getOne(array('utility_id'=>$this->utility_id));
			if(isPopArray($tmp))
			{
				foreach($tmp as $k => $i)
				{
					$this->utilitydata[$k] = $i;
				}
			}
			
		}
	}
	
	private function loadUtilityStates()
	{
		if(is_numeric($this->utility_id))
		{	
			$SQL = "Select us.*,uo.ongrid_file_id,uo.ongrid_key
			from utilities_states us
			left join ongrid_to_utilities uo
			on us.utility_state_id = uo.utility_state_id
			where us.utility_id = ".$this->utility_id.";";
			
			$result = $this->db->query($SQL);
			while($row = $result->fetchRow())
			{
				$tmp = $row;
			
				$UT = new utility_tariffs();
				$tmp['tariffs'] = $UT->get(array('utility_state_id'=>$row['utility_state_id']));

				$UM = new utility_multipliers();
				$tmp['multipliers'] = $UM->get(array('utility_state_id'=>$row['utility_state_id']));
				
				$this->utilitydata['state'][$row['utility_state_id']] = $tmp;
			}
		}
	}
	
	/**
	 * Save State
	 * 
	 * @param array $states
	 * <pre> array of 2 letter state string</pre>
	 * @return void
	 * @author Jason Ball
	 */
	public function saveUtilityStates($states)
	{
		$tmp = removeEmptyElements($states);

		$ot = $this->getStateList();
		
		foreach($tmp as $k => $i)
		{
			if(array_search($i,$ot) !== false)
			{
				
				unset($tmp[$k]);
				$row = array_search($i,$ot);
				unset($ot[$row]);
			}
		}
		
		$US = new utilities_states();
		//Delete unused states
		if(count($ot)>0)
		{
			$US->delete(array('utility_id'=>$this->utility_id,'state'=>$ot));
		}
		//Add New States
		
		if(count($tmp)>0)
		{
			foreach($tmp as $i)
			{
				$US->add(array('utility_id'=>$this->utility_id,'state'=>$i));	
			}
			
		}
		
		$this->loadUtilityStates();
	}
	
	/**
	 * This Method saves generic utility data
	 * @param array $in_args
	 * <pre>
	 * utility_provider
	 * utility_lease_defaults
	 * ongridfile
	 * resultedit
	 * </pre>
	 * @return void
	 * @author Jason Ball
	 * @copyright 08/27/01
	 */
	public function saveUtilityData($in_args)
	{
		
		$args = defaultArgs($in_args, array(
											'utility_provider'=>array(),
											'utility_lease_defaults'=>array(),
											'ongridfile'=>array(),
											
											'resultedit'=>array(
																'utility_miltipliers'=>array(),
																'utility_tariffs'=>array(),
																),
											));	
		
		
		if(isPopArray($args['utility_provider']))
		{
			if(!isValidPopDate($args['utility_provider']['archive']))
			{
				$args['utility_provider']['archive'] = null;	
			}
			$UP = new utility_providers();
			if(!is_numeric($this->utility_id))
			{
				
				
			}
			else
			{
				$UP->update(array('utility_id'=>$this->utility_id),$args['utility_provider']);
			}
			
			
		}
		
		if(is_numeric($this->utility_id))
		{
			if(isPopArray($args['ongridfile']) && is_numeric($this->currentstate))
			{
				$OTU = new ongrid_to_utilities();
				$OTU->addOrUpdate(array('utility_state_id'=>$this->currentstate), $args['ongridfile']);
				
			}
			
			if(isPopArray($args['utility_lease_defaults']))
			{
				$i = $args['utility_lease_defaults'];
				if(is_numeric($i['default_lease_term']))
				{
					$ULD = new utility_lease_defaults();
					$ULD->addOrUpdate(array('utility_id'=>$this->utility_id),$i);
				}
				
			}
			if(isPopArray($args['resultedit']['utility_multipliers']))
			{
				$UM = new utility_multipliers();
				foreach($args['resultedit']['utility_multipliers'] as $k => $i)
				{
					if(isSetNum($k))
					{
						$UM->update(array('utility_multiplier_id'=>$k),$i);
					}	
					
				}
				
			}
			if(isPopArray($args['resultedit']['utility_tariffs']) && is_numeric($this->currentstate))
			{
				$UT = new utility_tariffs();
				foreach($args['resultedit']['utility_tariffs'] as $k => $i)
				{
					if(!isSetNum($i['default']))
					{	
						$i['default'] = 0;
					}
					if(!isSetNum($i['preferred_solar']))
					{
						$i['preferred_solar'] = 0;
					}
				
					$UT->update(array('id'=>$k),$i);
						
					
				}
				
			}
			
			return $this->utility_id;
		}
		
	}
	
	public function getUtilityData($item)
	{
		return $this->getClassData($this->utilitydata,$item);
	}

	public function showStateUtilityData($utility_state_id)
	{
		if($this->error)
		{
			return $this->prettyFail($this->error);
		}
		$this->currentstate = $utility_state_id;
		return $this->showTemplate(getView('editutilitystatedata.php','utility'),$this);
	}

	/**
	 * This Method is used to get an array of tariffs that are attached to a utility
	 * 
	 * @param void()
	 * @return Array
	 * @author Jason Ball
	 * @copyright 08/29/2011
	 */
	public function getUtilityTariffs()
	{
		$tmp = array();
		
		
		if(isPopArray($this->utilitydata['state'][$this->currentstate]))
		{
			foreach($this->utilitydata['state'][$this->currentstate]['tariffs'] as $k => $i)
			{
				$tmp[] = $i['tariff_id'];
			}	
			
			return $tmp;
		}
		return array();
	}
	
	/**
	 * This Method will be used to get the abv list of states
	 * @param void
	 * @return array $array
	 * @author Jason Ball
	 * @copyright 08/20/2011
	 */
	public function getStateList()
	{
		$tmp = array();
		
		if(isPopArray($this->utilitydata['state']))
		{
			foreach($this->utilitydata['state'] as $k => $i)
			{
				
				$tmp[$k] = $i['state'];	
			}
			
		}
		return $tmp;
	}
	
	/** 
	 * This Method will delete the multipliers you have selected
	 *
	 * @param mixed $args all or array
	 * @return void()
	 * @author Jason Ball
	 * @copyright 08/27/2011
	 */
	public function removeUtilityMultipliers($args)
	{
		$UM = new utility_multipliers();
		
		if($args == 'all')
		{
			if(is_numeric($this->currentstate))
			{
				$UM->delete(array('utility_state_id'=>$this->currentstate));
			}
			
		}
		elseif(isPopArray($args))
		{
			foreach($args as $k)
			{
				$UM->delete(array('utility_multiplier_id'=>$k));
			}	
		}
		
	}
	
	/**
	 * This Method will delete the chosen states
	 * 
	 * @param array $states
	 * @author Jason Ball
	 * @return void
	 */
	public function removeUtilityStates($states)
	{
		$US = new utilities_states();
		if(isPopArray($states))
		{
			foreach($states as $i)
			{
				$US->delete(array('utility_state_id'=>$i));
			}	
		}
		
		$this->loadUtilityStates();
	}
	
	public function showAddTariffs()
	{
		return $this->showTemplate(getView('popups/addutilitytariffs.php','utility'),$this);	
	}
	
	public function showAttachTariffs()
	{
		return $this->showTemplate(getView('popups/attachutilitytariffs.php','utility'),$this);	
	}
	
	public function showAddMultiplier()
	{
		return $this->showTemplate(getView('popups/addmultipliers.php','utility'),$this);
	}
	
	public function showEditUtility()
	{
		return $this->showTemplate(getView('editutility.php','utility'),$this);
	}
	
	public function showUtilityStates()
	{
		return $this->showTemplate(getView('popups/utilitystates.php','utility'),$this);
		
	}
}
?>