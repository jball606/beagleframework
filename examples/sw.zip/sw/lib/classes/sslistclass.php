<?php
class sslistclass extends beaglelisttools
{
	private $gendef = "Please Select";	
	
	public function __construct($db="")
	{
		if($db == "V2DB")
		{
			global $V2DB;
			$db = $V2DB;
		}
		$this->loadListDB($db);	
		
	}
	
	public function userList($old="",$show="P",$in_args=array())
	{
		if(!is_array($in_args))
		{
			
			$in_args = array();
		}
		
		$args = defaultArgs($in_args, array('group_id'=>false,
											'inlist'=>false,
											'outoflist'=>false,
							));
		
		$SQL = "select user_id,concat(first_name,' ',last_name) as name
				from users u 
				where ( u.end_date is null or u.end_date >= now() or u.end_date = '0000-00-00')
				"; 
				
		if($args['inlist'])
		{
			$SQL .= " and u.user_id in (".$args['inlist'].") ";
		}
		
		if($args['outoflist'])
		{
			$SQL .= " and u.user_id not in (".$args['outoflist'].") ";
		}
		
		$SQL .= " order by name ASC ";

		return $this->SelectedGen('user_id','name',$SQL,$old,$this->gendef,$show);
	}
	
	public function groupUserType($old="",$show="P")
	{
		$SQL = "select * from group_user_type order by group_user_type;";
		
		return $this->SelectedGen('group_user_type_id','group_user_type',$SQL,$old,$this->gendef,$show);
			
	}

	public function ongridFiles($old="",$show="P")
	{
		$SQL = "Select * from ongrid_files order by file_key;";
		return $this->SelectedGen('ongrid_file_id', 'file_key', $SQL,$old,$this->gendef,$show);	
		
	}
	
	public function stateList($old="",$show="P",$in_args=array())
	{
		$SQL = "Select * from state where main = 'Y' and country_code = 'US' ";
		
		if(!is_array($in_args))
		{
			
			$in_args = array();
		}
		
		$args = defaultArgs($in_args, array(
											'inlist'=>false,
											'outoflist'=>false,
											));
		if($args['inlist'])
		{
			$SQL .= " and state.abv in (".$args['inlist'].") ";
		}
		
		if($args['outoflist'])
		{
			$SQL .= " and state.abv not in (".$args['outoflist'].") ";
		}
							
		$SQL .= " order by abv ASC;";
	
		return $this->SelectedGen('abv', 'name', $SQL,$old,$this->gendef,$show);
	}
	
	public function utilityProviders($old="",$show="P",$key="utility_id")
	{
		$SQL = "Select * from utility_providers order by name";
		return $this->SelectedGen($key, 'name', $SQL,$old,$this->gendef);	
		
	}
	
	public function multiplierTypes($old="",$show="P")
	{
		$SQL = "Select * from multiplier_types order by multiplier_type;";
		return $this->SelectedGen('multiplier_type_id', 'multiplier_type', $SQL,$old,$this->gendef,$show);
		
	}

	public function tariffs($old="",$show="P",$in_args=array())
	{
		$SQL = "Select * from tariffs where is_active = 1 ";

		if(!is_array($in_args))
		{
			
			$in_args = array();
		}
		
		$args = defaultArgs($in_args, array(
											'inlist'=>false,
											'outoflist'=>false,
											));
		if($args['inlist'])
		{
			$SQL .= " and tariff_id in (".$args['inlist'].") ";
		}
		
		if($args['outoflist'])
		{
			$SQL .= " and tariff_id not in (".$args['outoflist'].") ";
		}
		
		$SQL .= " order by tariff ASC";
			
		return $this->SelectedGen("tariff_id","tariff",$SQL,$old,$this->gendef,$show);
	}
}