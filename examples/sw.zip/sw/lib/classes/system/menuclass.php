<? 
class menuclass extends ssbaseclass
{
	private $menudata = array();
	private $menu_id = false;
	
	public function __construct($in_args = array())
	{
		$args = defaultArgs($in_args,array('menu_id'=>false));
		
		
		$this->loadSystemDB();
		$this->getInternalUser();
		
		if(!$this->userclass->isAdmin())
		{
			$this->error = "Invalid Access";
			return false;
		}
		
		if(is_numeric($args['menu_id']))
		{
			$this->loadMenu($args['menu_id']);
		}
		
	}
	
	public function getMenuData($item)
	{
		return $this->getClassData($this->menudata, $item);
	}
	
	private function loadMenu($menu_id)
	{
		if(is_numeric($menu_id))
		{
			$SM = new system_menus();
			$data = $SM->getOne(array('menu_id'=>$menu_id));
			$this->menudata = $data;
			$this->menu_id = $menu_id;	
		}
		
	}
	
	public function showEditMenu()
	{
		if($this->error)
		{
			return $this->prettyFail($this->error);
		}
		
		return $this->showTemplate(getView('systemadmin/editmenu.php',$this));	
	}	
	
}
?>