<?php
class ssbaseclass extends beaglebase
{
	protected $user_id = false;
	protected $userclass = false;
	
	/**
	 * Sets up the user class for the child class
	 * @param integer $upid
	 * @param integer $client_id
	 * @author Jason Ball
	 */
	protected function getInternalUser($upid="")
	{
		
		if(is_numeric($upid))
		{
			$this->user_id = $upid;
		}
		else if (isset($_SESSION['user_id']))
		{
			$this->user_id = $_SESSION['user_id'];
		}
		else
		{
			$this->user_id = false;
		}
		
		if($this->user_id == false)
		{
			return false;
		}
	
		$U = restoreClass('userclass');
		
		if(is_object($U) && $this->user_id == $U->getUserId())
		{
		
			$this->userclass = $U;
		}
		else if(is_numeric($this->user_id))
		{
			$this->userclass = new userclass(array('upid'=>$this->user_id));	
		}
		return true;
	}
	
}