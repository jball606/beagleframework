<?php
class groupclass extends ssbaseclass
{
	private $groupdata = array();
	private $group_id = false;
	
	public function __construct($in_args = array())
	{
		$args = defaultArgs($in_args,array('group_id'=>false));
		
		
		$this->loadSystemDB();
		$this->getInternalUser();
		
		if(is_numeric($args['group_id']))
		{
			$this->loadgroup($args['group_id']);
		}
		
	}
	
	/**
	 * Add Group to system
	 * @param array $groupdata
	 * @return string data or group id
	 * @author Jason Ball
	 * @copyright 2011-08-14
	 */
	private function addGroup($groupdata)
	{
		$G = new groups();
		
		if(!isValidPopDate($groupdata['start_date']))
		{
			$groupdata['start_date'] = $G->getPresets(array('start_date'));
		}
		
		$gs = $G->formatData($groupdata);
		
		$group_id = $G->add($gs);
		
		return $group_id;
	}
	
	/**
	 * Use this method to make sure the user had rights to change this group
	 * @param integer $group_id
	 * @return boolian
	 * @author Jason Ball
	 * @copyright 8/14/2011
	 */
	private function checkGroupAdmin($group_id)
	{
		if(is_object($this->userclass))
		{
			if($this->userclass->isAdmin())
			{
				return true;
			}
	
			$GU = new group_users();
			
			$user = $GU->getOne(array('group_id'=>$group_id,'user_id'=>$this->userclass->getUserId()),array('fields'=>array('group_user_type_id'),'limit'=>1));
			
			if(isPopArray($user))
			{
				switch($user['group_user_type_id'])
				{
					case 1:
					case 2:
					case 3:
						return true;
				}
			}
		}
		return false;
	}

	/**
	 * We don't want group name duplicates
	 * @param string $name
	 * @return boolian
	 * @author Jason Ball
	 * @copyright 08/14/2011
	 */
	private function checkGroupName($name)
	{
		$G = new groups();
		$want = array('lower(group_name)'=>strtolower($name));
		if(isSetNum($this->group_id))
		{
			$want['group_id !'] = $this->group_id;
		}
		
		$group_id = $G->getOne($want,array('fields'=>array('group_id'),'limit'=>1));	
		
		if(!$group_id)
		{
			return false;
		}
		
		return true;
	}
	
	public function getGroupData($item)
	{
		return $this->getClassData($this->groupdata,$item);
	}

	public function getGroupUsers()
	{
		$GU = new group_users();

		$row = $GU->get(array('group_id'=>$this->group_id));
		
		$tmp = array();
		foreach($row as $i)
		{
			$tmp[] = $i['user_id'];
		}
		
		return $tmp;
	}
	
	public function getUserListResult($in_args=array())
	{
		if(is_numeric($this->group_id))
		{
			$GUC = new group_users_controller();
			$GUC->driver = 'group';
			$GUC->setWhere(array('groups'=>array('group_id'=>$this->group_id)));
			return $GUC->showResultsPage($in_args);
		}
		
	}
	
	public function removeGroupUsers($users=array())
	{
	
		$GU = new group_users();
		if($users == 'all')
		{
			$GU->delete(array('group_id'=>$this->group_id));
		}
		elseif(isPopArray($users))
		{
			$GU->delete(array('group_id'=>$this->group_id,'user_id'=>$users));
		}
		
	}
	
	private function loadGroup($group_id)
	{
		if(isSetNum($group_id))
		{	
			if($this->checkGroupAdmin($group_id))
			{
				$G = new groups();
				$this->groupdata = $G->getOne(array('group_id'=>$group_id));	
				$this->group_id = $group_id;
			}
			else 
			{
				$this->error = "You do not have right to edit this group";
			}
			
		}
	}
	
	public function saveGroup($in_args)
	{
		$args = defaultArgs($in_args, array(
											'group'=>false,
											'useringroup'=>false,
						
											));

		if(isPopArray($args['group']))
		{
			$G = new groups();
			if($this->checkGroupName($args['group']['group_name']))
			{
				return "Group Name already in use";
			}
			
			if(!is_numeric($this->group_id))
			{
				$group_id = $this->addGroup($args['group']);
				
				if($group_id == false)
				{
					return $G->error;
				}
				
				$this->group_id = $group_id;
			}
			else 
			{
				$gd = $G->formatData($args['group']);
				$G->update(array('group_id'=>$this->group_id),$gd);
				
				
			}
			
			
		}
		if(isSetNum($this->group_id) && isPopArray($args['useringroup']))
		{
			$this->saveGroupUsers($args['useringroup']);	
			
		}
		
		return $this->group_id;
		
	}
	
	/**
	 * Method used to save group users and make sure to keep the group type settings of old ones
	 * @param array $users
	 * @return void
	 * @author Jason Ball
	 * @copyright 08/16/2011
	 */
	public function saveGroupUsers($users)
	{
		$UG = new group_users();
		$row = $UG->get(array('group_id'=>$this->group_id));
		$tmp = array();
		if(isPopArray($row))
		{
			foreach($row as $i)
			{
				$tmp[$i['user_id']] = $i['group_user_type_id'];
			}
		}
		
		
		$UG->delete(array('group_id'=>$this->group_id));
		
		foreach($users as $i)
		{
			if(is_numeric($i))
			{
				$type = 10;
				if(isset($tmp[$i]))
				{
					$type = $tmp[$i];
				}
			
				$UG->add(array(
								'group_id'=>$this->group_id,
								'user_id'=>$i,
								'group_user_type_id'=>$type,
							));
			
			}
		}
			
	}

	/**
	 * Use this method to update Group User type
	 * @param array $users
	 * @param integer $type
	 * @return void
	 * @author Jason Ball
	 * @copyright 08/16/2011
	 */
	public function saveGroupUserType($users,$type=10)
	{
		if(is_numeric($type) && is_numeric($this->group_id))
		{
			$UG = new group_users();
			
			if($users == 'all')
			{
				$UG->update(array('group_id'=>$this->group_id),array('group_user_type_id'=>$type));
			}
			else
			{
				$tmp = removeEmptyElements($users,'numeric');
				
				$UG->update(array('group_id'=>$this->group_id,'user_id'=>$users),array('group_user_type_id'=>$type));
			}
		}
	}
	
	public function showEditGroup()
	{
		if($this->error)
		{
			return $this->prettyFail($this->error);
		}
		
		return $this->showTemplate(getView('editgroup.php','systemadmin'),$this);
	}
	
	public function showGroupUsers()
	{
		return $this->showTemplate(getView('groupusers.php','systemadmin/popups'),$this);	
		
	}
}

?>