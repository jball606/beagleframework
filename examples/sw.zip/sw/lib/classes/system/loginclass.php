<?php
class loginclass extends ssbaseclass
{
	
	public function __construct()
	{
		$this->loadSystemDB();
	}
	
	public function loginUser($login,$password)
	{
		$U = new users();
		
		$row = $U->getOne(array('lower(email)'=>strtolower($login),'passwd'=>$password));
		
		
		if(isSetNum($row['user_id']))
		{
			$_SESSION['user_id'] = $row['user_id'];
			
			$U = new userclass(array('user_id'=>$row['user_id']));
			storeClass('userclass',$U);
			
			return 1;
		}
		
		return 0;
		
	}
	
	public function checkAccess($in_args = array())
	{
		$args = defaultArgs($in_args, array(
											'public'=>false,
											'ajax'=>false,
											'allusers'=>false,
											));

		$U = restoreClass('userclass');
		if($args['public'] == true)
		{
			return true;
		}
		
		if($U == false)
		{
			$this->logout();
			$this->goAway();
			return false;
		}
		
		//For Ajax Pages
		if($args['ajax'] == true && $U !== false)
		{
			return true;
		}
		//For All Users
		if($args['allusers'] == true && $U !== false)
		{
			return true;
		}
		
		if($U != false && $U->isAdmin())
		{
			return true;
		}
		
		$page = str_replace('/htdocs', '', $_SERVER['PHP_SELF']);
		
		
		$SQL = "select sm.menu_id
				from system_menus sm
					inner join menu_access ma
						on sm.menu_id = ma.menu_id
					left join group_users gu
						on ma.group_id = gu.group_id
				where sm.pagelink like '".$page."'
					and (ma.user_id = ".$U->getUserId();
		
		$groups = $U->getUserData('groups');
		
		if(isPopArray($groups))
		{
			$k = array_keys($groups);
			
			$SQL .= " or ma.group_id in (".implode(",", $k)."))";
		}
		else 
		{
			$SQL .= " ) ";
		}
		
		$id = $this->db->getOne($SQL);
		
		if(is_numeric($id))
		{
			return true;
		}
	
		$this->logout();
		$this->goAway();
		return false;
	}
	public function logout()
	{
		if(isset($_SESSION['userclass']))
		{
			unset($_SESSION['userclass']);
			unset($_SESSION['user_id']);
			
		}
		
		if(isset($_SESSION['user_id']))
		{
			unset($_SESSION['user_id']);
		}
		
			
	}
	
	public function goAway()
	{
		header("location:/index.php");
	}
}