<?php
class menusystemclass extends ssbaseclass
{
	private $menudata = false;
	private $children = false;
	private $admin = false;
	
	public function __construct($in_args = array())
	{
		$args = defaultArgs($in_args, array('user_id'=>false,
											'admin'=>false));

		
		$this->loadSystemDB();
		
		
		if(is_numeric($args['user_id']))
		{
			$this->user_id = $args['user_id'];
			$this->admin = $args['admin'];
		}
		
		
		$this->loadMenuSystem();
		
	}
	
	public function getMainMenu()
	{
		$tmp = array();
		if(isPopArray($this->menudata))
		{
			foreach($this->menudata as $i)
			{
				if($i['parent'] == 0)
				{
					$tmp[$i['menu_id']] = array('menu_name'=> $i['menu_name'],
												'link'=> $i['link']);
				}
				
			}
		}
		return $tmp;
		
	}
	
	public function getMenuList($menu_id)
	{
		if(isPopArray($this->menudata))
		{
			foreach($this->menudata as $i)
			{
				if($i['menu_id'] == $menu_id)
				{
					if(isPopArray($i['children']))
					{
						return $i['children'];
					}
				}
			}	
		}
	}
	
	private function loadMenuSystem()
	{
		$key['archived']=NULL;
		$key['system_menus.show'] = 1;
		if(isSetNum($this->user_id))
		{
			$plist = $this->getUserMenuList();
			
			$clist = $this->getUserMenuChildren();
			
			
			if(isPopArray($plist))
			{
				$key['menu_id'] = $plist;
			}
			
			if(isPopArray($clist))
			{
				foreach($clist as $i)
				{
					$key['menu_id'][] = $i;
				}
			}	
			
		}
		
		$SM = new system_menus();
		
		if(count($key)>2 || $this->admin == true)
		{
			$row = $SM->getByKey($key,array('orderby'=>'parent ASC, loc ASC'));
			if(isPopArray($row))
			{
				$bob = array();
				makeParentChildRelations($row, $bob, 'menu_id', 'parent');
			
				$this->menudata = $bob;
			}
		}
	}
	
	/**
	 * This method will get the children on any menu item the user has access to
	 */
	private function getUserMenuChildren()
	{
		$SQL = "Select group_id
		from group_users
		where user_id = ".$this->user_id."
		and group_id = 1;";
		
		$test = $this->db->getOne($SQL);
		
		if($test == 1)
		{
			return array();
		}
		
		$SQL = "select sm.menu_id
		from system_menus sm
		inner join menu_access ma
		on sm.menu_id = ma.menu_id
		where ma.user_id = ".$this->user_id."
		or ma.group_id in (select group_id
		from group_users where user_id = ".$this->user_id.")
		and sm.show = 1;";
		
		$list = $this->getChildrenMenuFilter($SQL);	
		
		return $list;
		
	}
	
	private function getChildrenMenuFilter($SQL)
	{
		$result = $this->db->query($SQL);
		$find = array();
		while($row = $result->fetchRow())
		{
			$find[$row['menu_id']] = $row['menu_id'];	
			
		}
		
		if(isPopArray($find))
		{
			$SQL = "select menu_id
			from system_menus sm
			where parent in (".implode(",",$find).");";
			
			$tmp =  $this->getChildrenMenuFilter($SQL);
			if(isPopArray($tmp))
			{
				$fm = array_merge($find,$tmp);
				return $fm;
			}
			else
			{
				return $find;
			}
		}
		else
		{
			return $find;
		}
		
		
	}
	
	/**
	 * 
	 * This method will get the parents of any menu items a user is connected to
	 */
	private function getUserMenuList()
	{
		
		$SQL = "Select group_id
		from group_users
		where user_id = ".$this->user_id."
		and group_id = 1;";
		
		$test = $this->db->getOne($SQL);
		
		if($test == 1)
		{
			return array();
		}
		
		$SQL = "select sm.menu_id,parent
		from system_menus sm
		inner join menu_access ma
		on sm.menu_id = ma.menu_id
		where ma.user_id = ".$this->user_id."
		or ma.group_id in (select group_id
		from group_users where user_id = ".$this->user_id.");";
		
		$list = $this->getMenuFilter($SQL);	
		
		return $list;
	
	}
	
	private function getMenuFilter($SQL)
	{
		$result = $this->db->query($SQL);
		$find = array();
		$found = "";
		while($row = $result->fetchRow())
		{
			if($row['parent'] != 0)
			{
				$find[] = $row['parent'];
			}
			$found[$row['menu_id']] = $row['menu_id'];	
			
		}
		
		if(isPopArray($find))
		{
			$SQL = "select menu_id,parent
			from system_menus sm
			where menu_id in (".implode(",",$find).");";
			
			$tmp =  $this->getMenuFilter($SQL);
			if(isPopArray($tmp))
			{
				if(isset($found))
				{
					$fm = array_merge($found,$tmp);
				}
				else 
				{
					$fm = $tmp;
				}
				return $fm;
			}
			else
			{
				return $found;
			}
		}
		else
		{
			return $found;
		}
		
			
	}
}
?>