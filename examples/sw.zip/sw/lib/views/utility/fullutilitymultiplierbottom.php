<ul class="image">
	<li class="plus link" title="Add Utility Multiplier" style="display:inline" onclick="umultiplier.addMultiplier(); return false;">&nbsp; Add Utility Multiplier</li>
	<li class="delete link delete_li" title="Remove Utility Multipliers" onclick="umultiplier.removeMultipliers(); return false;" style="display:inline">&nbsp; Remove Selected Multipliers</li>
</ul>
<ul class="error" id="utilitymultiplierbottomerror">
	
</ul>
