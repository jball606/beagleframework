<?php
/**
 * View of Edit States
 *
 * @package Solar Services
 * @subpackage Views / Utility
 * @author Jason Ball
 */


$list = new sslistclass('V2DB');
$record = $this->getUtilityData('all');
$tmp = $this->getUtilityData('state');
$current = $tmp[$this->currentstate];

?>
<div class="dblock_header">Utility State Information for <?=$list->stateList(getValue($current,'state'),'S');?></div>
	<table class="form">
		<tr>
			<td>Ongrid File</td>
			<td><select name="ongridfile[ongrid_file_id]"><?=$list->ongridFiles(getValue($current,'ongrid_file_id'));?></select></td>
		</tr>
		<tr>
			<td>Ongrid Key</td>
			<td><input type="text" class="longfield" name="ongridfile[ongrid_key]" value="<?=getValue($current,'ongrid_key');?>"/></td>
		</tr>
			
	</table>
	
		<div class="dblock innerright">
		<div class="dblock_header">Utility Multipliers</div>
	<script type="text/javascript">
		<!--
		var utilitymultipliersearch = new beagleResults({resultdiv:'utilitymultiplierlist',search:'utilitymultipliersearch'});
		
		utilitymultipliersearch.userFunction = function(field,id) 
		{ 
			/*	window.location.href="editgroup.php?utility_state_id="+utility_state_id; */
		};
		
		//-->
		</script>
		<div id="utilitymultiplierlist">
	<? 
		if(is_numeric($this->currentstate))
		{
			$UM = new utility_multipliers_controller();
			$UM->setWhere(array('utility_multipliers'=>array('utility_state_id'=>$this->currentstate)));
			print($UM->showResultsPage(array('lib'=>'utilitymultipliersearch','orderby'=>array('lease_term','multiplier_type'),'orderdir'=>array(1,1))));
			breadcrumbclass::storeBcSession('utilitymultipliersearch',$UM);
		}
	?>
		

	</div>
	</div>
	<br/>
	<div class="dblock innerright">
		<div class="dblock_header">Utility Tariffs</div>
	<script type="text/javascript">
		<!--
		var utilitytariffsearch = new beagleResults({resultdiv:'utilitytarifflist',search:'utilitytariffsearch'});
		
		utilitytariffsearch.userFunction = function(field,id) 
		{ 
			/*	window.location.href="editgroup.php?utility_state_id="+utility_state_id; */
		};
		
		//-->
		</script>
		<div id="utilitytarifflist">
	<? 
		if(is_numeric($this->currentstate))
		{
			$UT = new utility_tariffs_controller();
			$UT->setWhere(array('utility_tariffs'=>array('utility_state_id'=>$this->currentstate)));
			print($UT->showResultsPage(array('lib'=>'utilitytariffsearch')));
			breadcrumbclass::storeBcSession('utilitytariffsearch',$UT);
		}
	?>
		

	</div>
	</div>
