<?php
$record = $this->getUtilityData('all');
$list = new sslistclass('V2DB');
$utility_id = getValue($record,'utility_id');
?>

<div class="centerdiv">
	<script type="text/javascript">
	var utility = new utilityclass({utility_id:<?=getValue($record,'utility_id');?>});
	</script>
	
	
	<div id="utility_req_div" style="display:none">utility_name;utility_key</div>
	<input style="float:right" type="button" value="Submit" onclick="utility.verify(); return false;"/>
	<div style="float:left">
		<h1 class="pageheader" id="utilityheader">Edit Utility: <?=getValue($record,'name');?></h1>
		<? 
		if(isset($_GET['add']))
		{ ?><ul class="erroralert" id="error"><li>Record Updated</li></ul><? }
		else 
		{ ?><ul class="error" id="error"></ul><?  }
		?>
	</div>
	<div class="clearfloat"></div><br/>
	<? 
	if(is_numeric($utility_id))
	{
	?>
	<div class="dblock rightcol" id="statedata">
		<? 
			if(isset($record['state']) && count($record['state']) == 1)
			{
				$key = array_keys($record['state']);
				print($this->showStateUtilityData($key[0]));
				
			}
			else 
			{
				?><div class="dblock_header">Please select a state</div><? 	
			}
		?>
	</div>
	<? 
	}
	?>
	<div class="dblock leftcol">
		<div class="dblock_header">Utility Information</div>
		
		<table class="form">
			<tr>
				<td><label for="utility_name" id="utility_name_title">Name <span class="alert">*</span></label></td>
				<td><input type="text" class="longfield" name="utility_provider[name]" id="utility_name" value="<?=getValue($record,'name');?>"/></td>
			</tr>
			<tr>
				<td><label for="utility_key" id="utility_key_title">V2 Utility Key <span class="alert">*</span></label></td>
				<td><input type="text" class="longfield" name="utility_provider[key]" id="utility_key" value="<?=getValue($record,'key');?>"/></td>
			</tr>
			<tr>
				<td>Disable Utility</td>
				<td><input type="text" name="utility_provider[archive]" id="utility_archive" value="<?=getValue($record,'archive');?>"/></td>
				<script type="text/javascript">
					addcal('utility_archive');
				</script>
			<tr>
				<td>Default Down Payment</td>
				<td><input type="text" size="10" name="utility_lease_defaults[default_down_payment]" value="<?=getValue($record,'default_down_payment');?>"/></td>
			</tr>
			<tr>
				<td>Default Lease Terms</td>
				<td><input type="text" size = "2" name="utility_lease_defaults[default_lease_term]" value="<?=getValue($record,'default_lease_term');?>"/></td>
			</tr>
				
			<tr><td colspan="2">&nbsp;</td></tr>
			
		</table>
		<? if(is_numeric($utility_id))
		{
		?>
		<div class="dblock innerleft">
			<div class="dblock_header">States Linked to Utility</div>
			<script type="text/javascript">
			<!--
			var utilitystatesearch = new beagleResults({resultdiv:'utilitystatelist',search:'utilitystatesearch'});
			
			utilitystatesearch.userFunction = function(field,utility_state_id) 
			{ 
				utility.showStateData(utility_state_id);
			};
			
			//-->
			</script>
			<div id="utilitystatelist">
		<? 
			if(is_numeric(getValue($record,'utility_id')))
			{
				$GUC = new utilities_states_controller();
				$GUC->setWhere(array('utilities_states'=>array('utility_id'=>$record['utility_id'])));
				print($GUC->showResultsPage(array('lib'=>'utilitystatesearch')));
				breadcrumbclass::storeBcSession('utilitystatesearch',$GUC);
			}
		?>
			
	
			</div>
		</div>
		<? 
		}
		?>
	</div>
</div>