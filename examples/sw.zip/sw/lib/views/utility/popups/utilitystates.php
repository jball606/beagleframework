<? 
$sslist = new sslistclass('V2DB');
$states = "'".implode("','",$this->getStateList())."'";
?>
<div id="utilitystates_div_block" class="dblock" style="width:400px">
	<div class="dblock_header">States that this Utility operates in</div>
	<br/>
	<input type="button" value="Submit" onClick="utility.saveUtilityStates(); return false;" class="popupbutton">
	<div class="clearfloat"></div>
	<ul class="erroralert" id="utilitystates_error"></ul>
	<table class="form">
		<tr>
			<td>States Utility is In</td>
			<td></td>
			<td>States</td>
		</tr>
		<tr>
			<td>
				<select name="stateinutility[]" id="stateinutility" size="10" multiple>
					<?=$sslist->stateList("","P",array('inlist'=>$states));?>
				</select>
			</td>
			<td>
				<input type="button" onclick="addRemoveSelect('stateinutility','stateslist'); return false;" style="width:100px" value="<-- Add"/>
				<br/><br/>
				<input type="button" onclick="addRemoveSelect('stateslist','stateinutility'); return false;" style="width:100px" value="Remove -->"/>
			</td>
			<td>
				<select id="stateslist" name="stateslist" size="10" multiple>
					<?=$sslist->stateList("","P",array('outoflist'=>$states));?>
				</select>
			</td>
		</tr>
	</table>
</div>