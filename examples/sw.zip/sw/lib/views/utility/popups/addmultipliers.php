<? 
$sslist = new sslistclass('V2DB');
?>
<div style="display:none" id="mult_req">multiplier_type;lease_term;multiplier</div>
<div id="utilitymultiplier_div_block" class="dblock" style="width:400px">
	<div class="dblock_header">Add New Multiplier to Utility</div>
	<br/>
	<input type="button" value="Submit" onClick="utility.saveUtilityMultipliers(); return false;" class="popupbutton">
	<div class="clearfloat"></div>
	<ul class="erroralert" id="utilitymultiplier_error"></ul>
	<table class="form">
		<tr>
			<td><label for="multiplier_type" id="multiplier_type_title">Multiplier Type </label><span class="alert">*</span></td>
			<td>
				<select name="multiplier[multiplier_type_id]" id="multiplier_type">
					<?=$sslist->multiplierTypes();?>
				</select>
			</td>
		</tr>
		<tr>
			<td><label for="lease_term" id="lease_term_title">Lease Term </label><span class="alert">*</span></td>
			<td><input type="text" size="5" id="lease_term" name="multiplier[lease_term]"/></td>
		</tr>
		<tr>
			<td><label for="multiplier" id="multiplier_title">Multiplier </label><span class="alert">*</span></td>
			<td><input type="text" size="25" id="multiplier" name="multiplier[multiplier]"/></td>
		</tr>
	</table>
	
<br/>
</div>