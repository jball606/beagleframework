<? 
$sslist = new sslistclass('V2DB');
?>
<div style="display:none" id="mult_req">multiplier_type;lease_term;multiplier;utility_provider;utility_state</div>
<div id="utilitymultiplier_div_block" class="dblock" style="width:600px">
	<div class="dblock_header">Add New Multiplier</div>
	<br/>
	<input type="button" value="Submit" onClick="umultiplier.saveUtilityMultipliers(); return false;" class="popupbutton">
	<div class="clearfloat"></div>
	<ul class="erroralert" id="utilitymultiplier_error"></ul>
	
	<table class="form">
		<tr>
			<td><label for="utility_provider" id="utility_provider_title">Utility Provider </label><span class="alert">*</span></td>
			<td><select id="utility_provider" name="utility[utility_id]"><?=$sslist->utilityProviders();?></select></td>
		</tr>
		<tr>
			<td><label for="utility_state" id="utility_state_title">Utility State </label><span class="alert">*</span></td>
			<td><input type="text" size="2" name="utility[state]" id="utility_state"/></td>
		</tr>
		<tr>
			<td><label for="multiplier_type" id="multiplier_type_title">Multiplier Type </label><span class="alert">*</span></td>
			<td>
				<select name="multiplier[multiplier_type_id]" id="multiplier_type">
					<?=$sslist->multiplierTypes();?>
				</select>
			</td>
		</tr>
		<tr>
			<td><label for="lease_term" id="lease_term_title">Lease Term </label><span class="alert">*</span></td>
			<td><input type="text" size="5" id="lease_term" name="multiplier[lease_term]"/></td>
		</tr>
		<tr>
			<td><label for="multiplier" id="multiplier_title">Multiplier </label><span class="alert">*</span></td>
			<td><input type="text" size="25" id="multiplier" name="multiplier[multiplier]"/></td>
		</tr>
	</table>
	
<br/>
</div>