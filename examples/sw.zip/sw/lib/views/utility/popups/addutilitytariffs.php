<? 
$sslist = new sslistclass('V2DB');
$tariff = implode(",",$this->getUtilityTariffs());


?>
<div style="display:none" id="mult_req">multiplier_type;lease_term;multiplier</div>
<div id="utilitymultiplier_div_block" class="dblock" style="width:600px">
	<div class="dblock_header">Add New Tariffs to Utility</div>
	<br/>
	<input type="button" value="Submit" onClick="utility.saveUtilityMultipliers(); return false;" class="popupbutton">
	<div class="clearfloat"></div>
	<ul class="erroralert" id="utilitymultiplier_error"></ul>
	<table class="form">
		<tr>
			<td>States Utility is In</td>
			<td></td>
			<td>States</td>
		</tr>
		<tr>
			<td>
				<select name="stateinutility[]" id="stateinutility" size="10" multiple>
					<?=$sslist->tariffs("","P",array('inlist'=>$tariff));?>
				</select>
			</td>
			<td>
				<input type="button" onclick="addRemoveSelect('stateinutility','stateslist'); return false;" style="width:100px" value="<-- Add"/>
				<br/><br/>
				<input type="button" onclick="addRemoveSelect('stateslist','stateinutility'); return false;" style="width:100px" value="Remove -->"/>
			</td>
			<td>
				<select id="stateslist" name="stateslist" size="10" multiple>
					<?=$sslist->tariffs("","P",array('outoflist'=>$tariff));?>
				</select>
			</td>
		</tr>
	</table>
	
<br/>
</div>