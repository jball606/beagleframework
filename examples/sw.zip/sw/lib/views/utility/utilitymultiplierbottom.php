<ul class="image">
	<li class="plus link" title="Add Utility Multiplier" style="display:inline" onclick="utility.addMultiplier(); return false;">&nbsp; Add Utility Multiplier</li>
	<li class="delete link delete_li" title="Remove Utility Multipliers" onclick="utility.removeUtilityMultipliers(); return false;" style="display:inline">&nbsp; Remove Selected Multipliers from Utility</li>
</ul>
<ul class="error" id="utilitymultiplierbottomerror">
	
</ul>
