<ul class="image">
	<li class="plus link" title="Add States to Utility" style="display:inline" onclick="utility.addUtilityState(); return false;">&nbsp; Add States to Utility</li>
	<li class="delete link delete_li" title="Remove States to Utility" onclick="utility.removeUtilityStates(); return false;" style="display:inline">&nbsp; Remove Selected States from Utility</li>
</ul>
<ul class="error" id="utilitystatebottomerror">
	
</ul>
