<ul class="image">
	<li class="chain link" title="Link Utility Tariffs" style="display:inline" onclick="utility.attachTariffs(); return false;">&nbsp; Link Utility Tariffs</li>
	<li class="plus link" title="Add Utility Tariffs" style="display:inline" onclick="utility.addTariffs(); return false;">&nbsp; Add Utility Tariffs</li>
	<li class="delete link delete_li" title="Remove Utility Tariffs" onclick="utility.removeUtilityTariffs(); return false;" style="display:inline">&nbsp; Remove Selected Multipliers from Utility</li>
</ul>
<ul class="error" id="utilitytariffbottomerror">
	
</ul>
