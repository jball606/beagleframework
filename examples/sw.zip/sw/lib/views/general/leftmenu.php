<ol class="leftmenu">
<?=getMenu($result);?>


</ol>

<?php


function getMenu($array)
{
	if(isPopArray($array))
	{
		foreach($array as $k => $i)
		{
			?><li class="leftmenu">
				<? 
					if($i['link'] != "")
					{
					?>
						<a class="leftmenu" href="<?=$i['link'];?>?pcrumb=1"><?=$i['menu_name'];?></a>
				<? }
					else
					{	
						?><p class="menu_header"><?=$i['menu_name'];?></p> <? 
					} 
					
					if(isPopArray($i['children']))
					{
						?><ol class="leftmenu" style="padding-left:10px">
							<?=getMenu($i['children']);?>	
						
						</ol>
				<? }		
					?>
			</li>			
	<? 	
		
		}
	}
}

?>