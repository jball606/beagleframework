<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?

include_once("globalincludes.php");

if(isset($_GET['pcrumb']))
{
	if(isset($_SESSION['breadcrumbs']))
	{
		unset($_SESSION['breadcrumbs']);
	}
} 
?>
<title>Sungevity Solar Systems <? if(isset($pagename)) { print(" - ".$pagename); } ?></title>


<link href="/js/jquery/mask/jquery.loadmask.css" rel="stylesheet" type="text/css"></link>
<link href="/css/beaglestyles.css" rel="stylesheet" type="text/css"></link>
<link href="/css/style.css" rel="stylesheet" type="text/css"></link>


<link href="/css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css"></link>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--[if !IE 7]>
	<style type="text/css">
		#container {display:table;height:100%}
	</style>
<![endif]-->

<script type="text/javascript">
/* Language Setup */
 
 
var timer = new beagleTimer();
var beaglelogin = new beagleLogin();


 $.ajaxSetup({
 	type:"POST",
 	dataType:'json',
 	beforeSend:function() { timer.startWait(); },
 	error:function(a,b,c) 
 		{
 			alert(b+" \n "+c);
 			timer.fullUnmask(document.getElementById('container'));
 		
 		}
 });
</script>
</head>
<body>
<div id="container">
<div id="mainheader">
	<div id="header_menu">
		<ul id="primary_links">
		<? 
			if(is_object($user))
			{	?><li><a href="#" onclick="beaglelogin.systemLogout(); return false;">Sign Out</a></li><?  }
			else
			{ ?> <li><a href="/login.php">Sign In</a></li> <? }  ?>
		</ul>
		<div id="ss_header" onclick="window.location.href = '/index.php';"></div>
	

	</div>
		<? 

if(is_object($user))
{
	
//	print $user->showMenu();
	
	if(isset($pagename))
	{
		
		new breadcrumbclass($pagename);
	}

}

if(!isset($pagename))
{
	$pagename = false;
}

$GLOBALS['PAGENAME'] = $pagename;

?>
</div>
<div id="inner_container">
<?php 
if(is_object($user))
{
	?>
<div class="maintabset">
	<ul>
		<? 
			$menu = $user->getUserTabMenu();
			foreach($menu as $k=>$i)
			{
		?>
				<li>
					<a href="<?=$i['link'];?>?pcrumb=1"><?=$i['menu_name'];?></a>
				</li>
		<? 
			}
		?>
	</ul>
</div>
<?php } ?>
<table class="none" style="height:600px;" >

	<tr>
	<?php 
	if(is_object($user))
	{
		?>
		<td width="200px" id="global_side_menu">
		<?
			if(!isSetNum($menulist))
			{  
				$current_page = str_replace('/htdocs', '', $_SERVER['PHP_SELF']);
			
			
				$SQL = "select sm.parent
							from system_menus sm
										where sm.pagelink like '".$current_page."';";

				$current_page = $DB->getOne($SQL);
			}
			else 
			{
				$current_page = $menulist;
			}
				
			if(isSetNum($current_page))
			{
				echo $user->getMenuList($current_page);	
			}
		?>
		</td>
<? 
	}
?>
		<td id="contentcontainer">
		
		
