<? 
$sslist = new sslistclass();
?>
<div id="group_div_block" class="dblock" style="width:400px">
	<div class="dblock_header">Users in Group</div>
	<br/>
	<input type="button" value="Submit" onClick="group.saveGroupUsers(); return false;" class="popupbutton">
	<div class="clearfloat"></div>
	<ul class="erroralert" id="groupuser_error"></ul>
	<table class="form">
		<tr>
			<td>Users in Group</td>
			<td></td>
			<td>Users</td>
		</tr>
		<tr>
			<td>
				<select name="useringroup[]" id="useringroup" size="10" multiple>
					<?=$sslist->userList("","P",array('inlist'=>implode(",",$this->getGroupUsers())));?>
				</select>
			</td>
			<td>
				<input type="button" onclick="addRemoveSelect('useringroup','userslist'); return false;" style="width:100px" value="<-- Add"/>
				<br/><br/>
				<input type="button" onclick="addRemoveSelect('userslist','useringroup'); return false;" style="width:100px" value="Remove -->"/>
			</td>
			<td>
				<select id="userslist" name="userslist" size="10" multiple>
					<?=$sslist->userList("","P",array('outoflist'=>implode(",",$this->getGroupUsers())));?>
				</select>
			</td>
		</tr>
	</table>
</div>