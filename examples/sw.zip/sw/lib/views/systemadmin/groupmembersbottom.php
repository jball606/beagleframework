<? 
$list = new sslistclass();
?>
<ul class="image">
	<li class="group link" title="Add Users to Group" style="display:inline" onclick="group.addGroupUser(); return false;">&nbsp; Add Users to Group</li>
	<li class="delete link delete_li" title="Remove users from Group" onclick="group.removeGroupUsers(); return false;" style="display:inline">&nbsp; Remove Selected Users from Group</li>
</ul>
<ul class="image">
	<li style="display:inline">Selected group user type: <select id="groupusertype" name="groupusertype" onChange="group.showTypeButton(); return false;"><?=$list->groupUserType();?></select></li>
	<li style="display:none" id="typebutton"><input type="button" value="Update Types" onClick="group.updateTypes(); return false;"/></li> 
</ul>
<ul class="error" id="bottomerror">
	
</ul>
