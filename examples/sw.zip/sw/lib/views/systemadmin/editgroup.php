<?php
$record = $this->getgroupData('all');

?>

<div class="centerdiv">
<script type="text/javascript">
var group = new groupclass({group_id:<?=getValue($record,'group_id');?>});
</script>


<div id="group_req_div" style="display:none">group_name</div>
<input style="float:right" type="button" value="Submit" onclick="group.verify(); return false;"/>
<div style="float:left">
	<h1 class="pageheader">Edit group: <?=getValue($record,'group_name');?></h1>
	<? 
	if(isset($_GET['add']))
	{ ?><ul class="erroralert" id="error"><li>Record Updated</li></ul><? }
	else 
	{ ?><ul class="error" id="error"></ul><?  }
	?>
</div>
<div class="clearfloat"></div><br/>
<div class="dblock">
	<div class="dblock_header">Group Information</div>
	
	<table class="form">
		<tr>
			<td width="100px"><label for="group_name" id="group_name_title">Group Name </label><span class="alert">*</span></td>
			<td><input type="text" class="longfield" name="group[group_name]" id="group_name" value="<?=getValue($record,'group_name');?>"/></td>
		</tr>
		<tr>
			<td><label for="start_date" id="start_date_title">Start Date </label><span class="alert">*</span></td>
			<td><input type="text" id="start_date" name="group[start_date]" value="<? (getDateValue($record,'start_date') != false) ? print(getDateValue($record,'start_date')) : print(date("m/d/Y")); ?>"/></td>
		</tr>
		<? 
			if(getValue($record,'group_id') != 1)
			{
		?>
		<tr>
			<td>End Date</td>
			<td><input type="text" id="end_date" name="group[end_date]" value="<?=getDateValue($record,'end_date');?>"/></td>
		</tr>
		<? 
			}
		?>
		<script type="text/javascript">
			addcal('start_date');
			addcal('end_date');
		</script>
	</table>
</div>

<br/>
<script type="text/javascript" src="/js/beaglejs/beagleResults.js"></script>
<script type="text/javascript">
<!--
var groupsearch = new beagleResults({resultdiv:'groupuserlist',search:'groupsearch'});

groupsearch.userFunction = function(field,group_id) 
			{ 
				window.location.href="editgroup.php?group_id="+group_id;
			};

//-->
</script>
<div class="dblock">
	<div class="dblock_header">Group Users Management</div>
	<div id="groupuserlist">
	<? 
		if(is_numeric(getValue($record,'group_id')))
		{
			$GUC = new group_users_controller();
			$GUC->driver = 'group';
			$GUC->setWhere(array('groups'=>array('group_id'=>$record['group_id'])));
			print($GUC->showResultsPage(array('lib'=>'groupsearch')));
			breadcrumbclass::storeBcSession('groupsearch',$GUC);
		}
	?>
		

	</div>
</div>


