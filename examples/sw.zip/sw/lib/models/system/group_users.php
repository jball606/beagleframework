<?php
class group_users extends beagledbclass
{
	protected $table = "group_users";
	
	protected $valid_fields = array('group_id'=>array(
														'type'=>'integer',
														'null'=>false
													),
									
									'user_id'=>array(
														'type'=>'integer',
														'null'=>false,
													),
									'group_user_type_id'=>array(
																'type'=>'integer',
																'default'=>10,
																'null'=>false
																),
	
									);
}
?>