<?php
class users extends beagledbclass
{
	protected $table = "users";
	protected $pkey = "user_id";
	protected $auditing = true;
	
	protected $valid_fields = array('end_date'=>array('type'=>'date',
														'preset'=> '',
														'output'=>'Y-m-d'),
									
									'start_date'=>array('type'=>'date',
														'preset'=> '',
														'output'=>'Y-m-d'),
									'email'=>array('type'=>'email',
															'null'=>false),
									
									'first_name'=>array('type'=>'varchar',
																'size'=>255,
																'null'=>false),
									
									'last_name'=>array('type'=>'varchar',
														'size'=>255,
														'null'=>false),
	
									);
	
	public function __construct()
	{
		$this->valid_fields['start_date']['preset'] = dbNow();
	}
}
?>