<?php
class system_menus extends beagledbclass
{
	protected $table = "system_menus";
	protected $pkey = "menu_id";
	protected $auditing = true;
	
	protected $valid_fields = array('archived'=>array('type'=>'date',
														'preset'=> '',
														'output'=>'Y-m-d H:i:s'),
									
									'menu_name'=>array('type'=>'varchar',
														'size'=>255,
														'null'=>false),
									
									'link'=>array('type'=>'varchar',
													'size'=>255),
									
									'loc'=>array('type'=>'integer',
														'null'=>false),
	
									);
	
	
}
?>