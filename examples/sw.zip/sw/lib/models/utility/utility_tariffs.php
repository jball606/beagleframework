<?php
class utility_tariffs extends ssdbclass
{
	protected $table = "utility_tariffs";
	protected $pkey = "id";
	
	
	protected $valid_fields = array('utility_state_id'=>array(
													'type'=>'integer',
													'null'=>false
												),
									
									'tariff_id'=>array(
													'type'=>'integer',
													'null'=>false
												),
									);
	
	public function __construct()
	{
		global $V2DB;
		$this->db = $V2DB;	
		
	}
}
?>