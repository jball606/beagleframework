<?php
/**
 * This is the utilities_states model
 *
 * @author Jason Ball
 * @package Solar Services
 * @subpackage Models
 *
 */
class utilities_states extends ssdbclass
{
	protected $table = "utilities_states";
	protected $pkey = "utility_state_id";
	
	
	protected $valid_fields = array('utility_id'=>array(
														'type'=>'integer',
														'null'=>false
												),
									
									'state'=>array(
													'type'=>'varchar',
													'size'=> 2,
													'null'=>false
												),
									);
	
	public function __construct()
	{
		global $V2DB;
		$this->db = $V2DB;	
		
	}



}
?>