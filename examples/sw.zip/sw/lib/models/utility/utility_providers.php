<?php
class utility_providers extends ssdbclass
{
	protected $table = "utility_providers";
	protected $pkey = "utility_id";
	
	
	protected $valid_fields = array('name'=>array(
													'type'=>'varchar',
													'size'=>255,
													'null'=>false
												),
									
									'key'=>array(
													'type'=>'varchar',
													'size'=> 255,
													'null'=>false
												),
									'country_code'=>array(
															'type'=>'varchar',
															'size'=>2,
															'null'=>false,
															'preset'=>'US'
														),
									'archive'=>array(
														'type'=>'date',
													),
	
									);
	
	public function __construct()
	{
		global $V2DB;
		$this->db = $V2DB;	
		
	}
	
}
?>