<?php
/**
 * This is the ongrid_to_utilities model
 *
 * @author Jason Ball
 * @package Solar Services
 * @subpackage Models
 *
 */
class ongrid_to_utilities extends ssdbclass
{
	protected $table = "ongrid_to_utilities";
	protected $pkey = "utility_state_id";
	
	
	protected $valid_fields = array('ongrid_file_id'=>array(
															'type'=>'integer',
															'null'=>false
														),
									
									'ongrid_key'=>array(
													'type'=>'varchar',
													'size'=> 255,
													'null'=>false
												),
									);
	
	public function __construct()
	{
		global $V2DB;
		$this->db = $V2DB;	
		
	}



}
?>