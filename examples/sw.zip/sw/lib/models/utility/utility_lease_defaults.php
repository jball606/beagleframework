<?php
/**
 * Utility Lease Default Method
 *
 * @author Jason Ball
 * @package Solar Services
 * @subpackage Models
 *
 */
class utility_lease_defaults extends ssdbclass
{
	protected $table = "utility_lease_defaults";
	protected $pkey = "utility_id";
	
	
	protected $valid_fields = array('utility_id'=>array(
															'type'=>'integer',
															'null'=>false
															),
									
									'default_down_payment'=>array(
														'type'=>'numeric',
														'null'=>false,
														'preset'=>'0.00',
														),
									'default_lease_term'=>array(
																'type'=>'integer',
																'null'=>false
																),
									);
	
	public function __construct()
	{
		global $V2DB;
		$this->db = $V2DB;	
		
	}
}
?>