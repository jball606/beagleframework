<?php
class utility_multipliers extends ssdbclass
{
	protected $table = "utility_multipliers";
	protected $pkey = "utility_multiplier_id";
	
	
	protected $valid_fields = array('utility_state_id'=>array(
															'type'=>'integer',
															'null'=>false
															),
									
									'lease_term'=>array(
														'type'=>'integer',
														'null'=>false
														),
									'multiplier_type_id'=>array(
																'type'=>'integer',
																'null'=>false
																),
									'multiplier'=>array(
														'type'=>'numeric',
														'null'=>false
														),
									);
	
	public function __construct()
	{
		global $V2DB;
		$this->db = $V2DB;	
		
	}

	
}
?>