<?php
/**
 * This is the sized_systems model
 *
 * @author Jason Ball
 * @package Solar Services
 * @subpackage Models
 *
 */
class sized_systems extends ssdbclass
{
	protected $table = "sized_systems";
	protected $pkey = "id";
	
	/*
	protected $valid_fields = array('ongrid_file_id'=>array(
															'type'=>'integer',
															'null'=>false
														),
									
									'ongrid_key'=>array(
													'type'=>'varchar',
													'size'=> 255,
													'null'=>false
												),
									);*/
	
	
	public function __construct()
	{
		global $V2DB;
		$this->db = $V2DB;	
		
	}



}
?>