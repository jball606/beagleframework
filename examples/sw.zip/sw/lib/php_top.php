<?php
require_once("config/systemsetup.php");
include(getView("top.php","general"));
$L = new loginclass();
if(!isset($accessparam))
{
	$accessparam = array();
}
if(!$L->checkAccess($accessparam))
{
	exit;
}
?>