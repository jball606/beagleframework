<?php
include_once(getView("bottom.php","general"));
?>