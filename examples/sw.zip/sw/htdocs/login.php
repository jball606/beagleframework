<?php
$accessparam['public'] = 1;
include("php_top.php");

?>


<form id="loginform" method="post">

<? 
include(getView("login.php","general"));
?>


</form>
<style type="text/css">
#global_side_menu
{
display:none;
}
</style>
<? 
include("php_bottom.php");
?>