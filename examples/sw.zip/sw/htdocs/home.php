<?php
$accessparam['allusers'] = 1;
include("php_top.php");

$U = restoreClass('userclass');


	

print_r2($U);

include("php_bottom.php");
?>