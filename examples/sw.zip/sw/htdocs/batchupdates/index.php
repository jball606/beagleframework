<?php
$pagename = "Batch Updates";
$menulist = 14;
include("php_top.php");


breadcrumbclass::showBcChain();
?>
<h1><?=$pagename;?></h1>

<? 
include("php_bottom.php");
?>