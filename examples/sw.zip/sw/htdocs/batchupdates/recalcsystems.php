<?php
$pagename = "Recalc Systems";
include("php_top.php");

if(isset($_POST['calc']))
{
	set_time_limit(300);
	$ids = explode(",", $_POST['ssid']);
	
	$SS = new sized_systems();
	
	foreach($ids as $i)
	{
		$fix = array(
						'price_override'=>null,
						'lease_multiplier_override'=>null,
						'down_payment_multiplier_override'=>null,
						'modified'=>dbNow(),
						);
		if(is_numeric($i))
		{
			
			$SS->update(array('id'=>$i),$fix);
			
		}
		
	}
}

breadcrumbclass::showBcChain();
?>
<h1><?=$pagename;?></h1>
<? 
if(isSetNum($_POST['calc']))
{
	if(empty($_POST['ssid']))
	{ 
		?><ul class="erroralert"><li>No Systems Entered</li></ul> <? 
	}
	else 
	{
		?><ul class="erroralert"><li>Systems are now in the recalc queue</li></ul>
		
	<? 
	}
}
?>

<form method="post" action="<?=$_SERVER['PHP_SELF'];?>">
<input type="hidden" name="calc" value="1"/>
Please put a comma deliminated list of sized system <b>ID</b>s into the text box that you want to turn soft and have recalulated<br/>
<textarea rows="25" cols="150" name="ssid"></textarea>
<br/>
<input type="submit" value="Submit Systems"/>
</form>

<? 
include("php_bottom.php");
?>