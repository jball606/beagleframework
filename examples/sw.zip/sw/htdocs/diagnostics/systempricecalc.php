<?php
$pagename = "System Price Calculations";
$menulist = 16;
include("php_top.php");

if(isSetNum($_POST['ssprice']) || issetNum($_GET['ssprice']))
{
	if(isSetNum($_GET['ssprice']))
	{
		$ssprice = $_GET['ssprice'];
	}
	else 
	{
		$ssprice = $_POST['ssprice'];
	}
	
	
	$SQL = "Select * from sized_systems where id = ".$ssprice.";";
	$sized_sytems = $V2DB->query($SQL)->fetchRow();
	
	
	$SQL = "Select * from system_templates where id = ".$sized_systems['system_template_id'].";";
	$system = $V2DB->query($SQL)->fetchRow();
	
	$SQL = "Select ssa.*,
			from sized_system_adders ssa
				inner join adder_templates at
					on ssa.adder_template_id = at.id
			where sized_system_id = ".
	
}
?>

<form method="post" action="<?=$_SERVER['PHP_SELF'];?>">
	<input type="hidden" name="calc" value="1"/>
	Please input system number <br/>
	<input type="text" name="ssprice" />
	<input type="submit" />
</form>
<? 
include("php_bottom.php");
?>