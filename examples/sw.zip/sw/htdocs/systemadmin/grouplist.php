<?php
$pagename = "Group List";
$menulist = 1;
include("php_top.php");

if(!$GC = breadcrumbclass::getLastBCSession('groupsearch'))
{
	$GC = new groups_controller();

}

breadcrumbclass::showBcChain();
?>
<h1><?=$pagename;?></h1>

<ul class="image">
	<li class="group"><a href="editgroup.php">Add New Group</a></li>

</ul>
<script type="text/javascript" src="/js/beaglejs/beagleResults.js"></script>
<script type="text/javascript">
<!--
var groupsearch = new beagleResults({resultdiv:'grouplist',search:'groupsearch'});

groupsearch.userFunction = function(field,group_id) 
			{ 
				window.location.href="editgroup.php?group_id="+group_id;
			};

//-->
</script>

<div id="grouplist">
<?=$GC->showResultsPage(array('lib'=>'groupsearch'));?>
</div>

<? 
breadcrumbclass::storeBcSession('groupsearch',$GC); 
include("php_bottom.php");
?>