<?php
$pagename = "Menu List";
$menulist = 1;
include("php_top.php");

if(!$UC = breadcrumbclass::getLastBCSession('menusearch'))
{
	$UC = new system_menus_controller();

}

breadcrumbclass::showBcChain();
?>
<h1><?=$pagename;?></h1>

<ul class="image">
	<li class="person"><a href="edituser.php">Add New User</a></li>

</ul>
<script type="text/javascript" src="/js/beaglejs/beagleResults.js"></script>
<script type="text/javascript">
<!--
var menusearch = new beagleResults({resultdiv:'menulist',search:'menusearch'});

menusearch.userFunction = function(field,menu_id) 
			{ 
				window.location.href="editmenu.php?menu_id="+menu_id;
			};

//-->
</script>

<div id="menulist">
<?=$UC->showResultsPage(array('lib'=>'menusearch'));?>
</div>

<? 
breadcrumbclass::storeBcSession('menusearch',$UC); 
include("php_bottom.php");
?>