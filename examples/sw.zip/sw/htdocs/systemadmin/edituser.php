<?php
$menulist = 1;
include_once("config/systemsetup.php");

$user_id = false;
if(isSetNum($_GET['user_id']))
{
	$user_id = $_GET['user_id'];
}

$U = new userclass(array('user_id'=>$user_id));

$row = $U->getUserData('all');

if(getValue($row,'first_name') != false)
{
	$pagename = getValue($row,'first_name')." ".getValue($row,'last_name');
}
else 
{
	$pagename = "New User";
}

include("php_top.php");
?>
<script type="text/javascript" src="/js/systemadmin/user.js"></script>
<? 
breadcrumbclass::showBcChain();
?>

<form id="useradd">
<?=$U->showEditUser();?>
</form>

<? 
breadcrumbclass::storeBCSession('edituser', $U);
include("php_bottom.php");
?>