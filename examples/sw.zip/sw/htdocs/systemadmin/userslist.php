<?php
$pagename = "User List";
$menulist = 1;
include("php_top.php");

if(!$UC = breadcrumbclass::getLastBCSession('usersearch'))
{
	$UC = new users_controller();

}

breadcrumbclass::showBcChain();
?>
<h1><?=$pagename;?></h1>

<ul class="image">
	<li class="person"><a href="edituser.php">Add New User</a></li>

</ul>
<script type="text/javascript" src="/js/beaglejs/beagleResults.js"></script>
<script type="text/javascript">
<!--
var usersearch = new beagleResults({resultdiv:'userlist',search:'usersearch'});

usersearch.userFunction = function(field,user_id) 
			{ 
				window.location.href="edituser.php?user_id="+user_id;
			};

//-->
</script>

<div id="userlist">
<?=$UC->showResultsPage(array('lib'=>'usersearch'));?>
</div>

<? 
breadcrumbclass::storeBcSession('usersearch',$UC); 
include("php_bottom.php");
?>