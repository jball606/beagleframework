<?php
$menulist = 1;
include_once("config/systemsetup.php");

$group_id = false;
if(isSetNum($_GET['group_id']))
{
	$group_id = $_GET['group_id'];
}
$G = new groupclass(array('group_id'=>$group_id));

$row = $G->getGroupData('all');

if(getValue($row,'group_name') != false)
{
	$pagename = getValue($row,'group_name');
}
else 
{
	$pagename = "New Group";
}

include("php_top.php");
?>
<script type="text/javascript" src="/js/systemadmin/group.js"></script>
<? 
breadcrumbclass::showBcChain();
?>

<form id="groupadd">
<?=$G->showEditgroup();?>
</form>

<? 
breadcrumbclass::storeBCSession('editgroup', $G);
include("php_bottom.php");
?>