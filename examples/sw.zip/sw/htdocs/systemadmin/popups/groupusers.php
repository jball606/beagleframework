<?php
include("config/systemsetup.php");
if(!$C =  breadcrumbclass::restoreBcSession('editgroup'))
{ 
	?><ul class="erroralert"><li>Invalid Group</ul><?
	exit;
}
?>

<?
$group_id = false;
if(isSetNum($_GET['group_id']))
{
	$group_id = $_GET['group_id'];
}
$G = new groupclass(array('group_id'=>$group_id));
?>

<form id="groupuseradd">
<div id="grouppage_div">
<? 
echo $G->showGroupUsers();
?>
</div>
</form>
