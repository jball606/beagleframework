<?php
$menulist = 1;
include_once("config/systemsetup.php");

$menu_id = false;
if(isSetNum($_GET['menu_id']))
{
	$menu_id = $_GET['menu_id'];
}
$M = new menuclass(array('menu_id'=>$menu_id));

$row = $M->getmenuData('all');

if(getValue($row,'menu_name') != false)
{
	$pagename = getValue($row,'menu_name');
}
else 
{
	$pagename = "New menu";
}

include("php_top.php");
?>
<script type="text/javascript" src="/js/systemadmin/menu.js"></script>
<? 
breadcrumbclass::showBcChain();
?>

<form id="menuadd">
<? $M->showEditmenu();?>
</form>

<? 
breadcrumbclass::storeBCSession('editmenu', $M);
include("php_bottom.php");
?>