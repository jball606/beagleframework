<?php
$ajax_page="Y";

include_once("config/systemsetup.php");

if(isset($_GET['id']))
{
	$info = $_GET;
}
else 
{
	$info = $_POST;
}


if(isset($info['id']))
{
	switch($info['id'])
	{
		case "breadcrumb":
		{
			breadcrumbclass::resetToId($info['bcid']);
			$BC = breadcrumbclass::getLastBC();
			print json_encode(array('url'=>$BC->getBcUrl()));
			break;
			
		}
		case "resettab":
		{
			breadcrumbclass::clearLastBC();
			break;		
		}
		case "pickclient":
		{
			if($U = restoreClass('userclass') && isSetNum($info['client_id']))
			{	
				$_SESSION['client_id'] = $info['client_id'];
				
				$U = new userclass(array('upid'=>$_SESSION['upid'],'client_id'=>$info['client_id']));
				storeClass('userclass', $U);
				print json_encode(array('good'=>'good'));
			
			}
			break;		
		}
	}
	
}
?>				