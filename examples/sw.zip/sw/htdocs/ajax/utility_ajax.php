<?php
$ajax_page="Y";

include_once("config/systemsetup.php");
$L = new loginclass();
if(!$L->checkAccess())
{
	exit;
}

if(isset($_POST))
{
	$info = $_POST;
}

if(isset($info['id']))
{
	switch($info['id'])
	{
		case "utilitysave":
		{
			if($GC = breadcrumbclass::restoreBcSession('editutility'))
			{
				$uid = $GC->saveUtilityData($info);
				print json_encode(array('error'=>$uid));
			}	
			break;
		}
		case "removefullmultiplier":
		{
			if($S = restorePageClass($info['search']))
			{	
				$sel = $S->getSelected();
				
				if($sel == 'all')
				{
					print json_encode(array('error'=>'You can\'t delete all the multipliers'));
					break;
				}
				else 
				{
					$S->removeUtilityMultipliers($sel['selected']);
				}
				print json_encode(array('utility_multiplier_id'=>1));
			}	
			
			break;		
		}
		case "addfullutilitymultiplier":
		{
			$UMC = new utility_multipliers_controller();
			$mid = $UMC->addNewMultlipleir($info);
			if(is_numeric($mid))
			{
				print json_encode(array('utility_multiplier_id'=>$mid));
			}
			else 
			{
				print json_encode(array('error'=>$mid));
			}
			break;	
		}
		case "getutilitystatedata":
		{
			if($GC = breadcrumbclass::restoreBcSession('editutility'))
			{
				if(!is_numeric($GC->getUtilityData('utility_id')))
				{
					print json_encode(array("error"=>"Invalid Utility"));
					break;
				}
				
				$tmp = $GC->showStateUtilityData($info['utility_state_id']);
				
				print json_encode(array('html'=>$tmp));
			}
			break;		
		}
		case "addutilitymultiplier":
		{
			
			if($GC = restorePageClass('editutility'))
			{
				if(!is_numeric($GC->getUtilityData('utility_id')))
				{
					print json_encode(array("error"=>"Invalid Utility"));
					break;
				}
				
				$minfo = $GC->addUtilityMultiplier($info['multiplier']);
				
				if(!is_numeric($minfo))
				{
					print json_encode(array('error'=>$minfo));
				}
				else 
				{
					print json_encode(array('utility_multiplier_id'=>$minfo));
				}
			}
			break;		
		}
		case "removegivenutilitymultipliers":
		{
			if($GC = restorePageClass('editutility'))
			{
				if(!is_numeric($GC->getUtilityData('utility_id')))
				{
					print json_encode(array("error"=>"Invalid Utility"));
					break;
				}
				
				if($S = restorePageClass($info['search']))
				{	
					$sel = $S->getSelected();
					if($sel == 'all')
					{
						$GC->removeUtilityMultipliers('all');
						break;
					}
					else 
					{
						$GC->removeUtilityMultipliers($sel['selected']);
					}
					print json_encode(array('utility_id'=>$GC->getUtilityData('utility_id')));
				}
					
				storePageClass('editutility', $GC);
				
			}	
			break;		
		}
		case "removeutilitystates":
		{
			
			if($GC = breadcrumbclass::restoreBcSession('editutility'))
			{
				if(!is_numeric($GC->getUtilityData('utility_id')))
				{
					print json_encode(array("error"=>"Invalid Utility"));
					break;
				}
				
				if($S = breadcrumbclass::restoreBcSession($info['search']))
				{	
					$sel = $S->getSelected();
					if($sel == 'all')
					{
						print json_encode(array('error'=>"You can not delete all states from a utility"));
						break;
					}
					else 
					{
						$GC->removeUtilityStates($sel['selected']);
					}
					print json_encode(array('utility_id'=>$GC->getUtilityData('utility_id')));
				}
					
				storePageClass('editutility', $GC);
				
			}
			break;		
		}
		case "saveutilitystates":
		{
			if($GC = breadcrumbclass::restoreBcSession('editutility'))
			{
				if(!is_numeric($GC->getUtilityData('utility_id')))
				{
					print json_encode(array("error"=>"Invalid Utility"));
					break;
				}
				if(!isset($info['stateinutility']) || count(removeEmptyElements($info['stateinutility'])) == 0)
				{
					print json_encode(array("error"=>"You must select 1 state"));
					break;
				}	
				$GC->saveUtilityStates($info['stateinutility']);
				print json_encode(array('utility_id'=>$GC->getUtilityData('group_id')));
				
				storePageClass('editutility', $GC);
				
			}
			break;		
		}
			
		
	}
}
?>