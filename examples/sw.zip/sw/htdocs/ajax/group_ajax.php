<?php
$ajax_page="Y";

include_once("config/systemsetup.php");


if(isset($_POST))
{
	$info = $_POST;
}

if(isset($info['id']))
{
	switch($info['id'])
	{
		case "updateusertype":
		{
			if($GC = breadcrumbclass::restoreBcSession('editgroup'))
			{
				if(!is_numeric($GC->getGroupData('group_id')))
				{
					print json_encode(array("error"=>"Invalid Group"));
					break;
				}
				
				if($S = breadcrumbclass::restoreBcSession($info['search']))
				{	
					$sel = $S->getSelected();
					if($sel == 'all')
					{
						$GC->saveGroupUserType('all',$info['usertype']);
					}
					else 
					{
						$GC->saveGroupUserType($sel['selected'],$info['usertype']);
					}
					$S->resetCheck();
					breadcrumbclass::storeBcSession($info['search'],$S);
					print json_encode(array('group_id'=>$GC->getGroupData('group_id')));
				}
					
				
			}
			break;		
				
		}
		case "groupsave":
		{
			if($GC = breadcrumbclass::restoreBcSession('editgroup'))
			{
				$new = false;
			
				if(!is_numeric($GC->getGroupData('group_id')))
				{
					$new = true;
				}
				
				$array = array();
				$array = $info;
					
				$group_id = $GC->saveGroup($array);
			
				if(!is_numeric($group_id))
				{
					print json_encode(array('error'=>$group_id));
					break;
				}
					
				print json_encode(array('group_id'=>$group_id));
				
				breadcrumbclass::storeBcSession('editgroup',$GC);
					
				if($new == true)
				{
					breadcrumbclass::clearLastBC();
				}
							
					
			}
			else 
			{
				print json_encode(array("error"=>1));
					
			}
			
			break;
			
		}
		case "removegroupusers":
		{
			
			if($GC = breadcrumbclass::restoreBcSession('editgroup'))
			{
				if(!is_numeric($GC->getGroupData('group_id')))
				{
					print json_encode(array("error"=>"Invalid Group"));
					break;
				}
				
				if($S = breadcrumbclass::restoreBcSession($info['search']))
				{	
					$sel = $S->getSelected();
					if($sel == 'all')
					{
						$GC->removeGroupUsers('all');
					}
					else 
					{
						$GC->removeGroupUsers($sel['selected']);
					}
					print json_encode(array('group_id'=>$GC->getGroupData('group_id')));
				}
					
				
			}
			break;		
		}
		case "savegroupusers":
		{
			if($GC = breadcrumbclass::restoreBcSession('editgroup'))
			{
				if(!is_numeric($GC->getGroupData('group_id')))
				{
					print json_encode(array("error"=>"Invalid Group"));
				}
			
				$GC->saveGroupUsers($info['useringroup']);
				
				print json_encode(array('group_id'=>$GC->getGroupData('group_id')));
			}
			break;
		}
	}
}