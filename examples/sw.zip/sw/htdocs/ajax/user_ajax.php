<?php
$ajax_page="Y";

include_once("config/systemsetup.php");

if(isset($_POST))
{
	$info = $_POST;
}

if(isset($info['id']))
{
	switch($info['id'])
	{
		case "usersave":
		{
			if($UC = breadcrumbclass::restoreBcSession('edituser'))
			{
				$new = false;
				if(!is_numeric($UC->getUserData('user_id')))
				{
					$new = true;
				}
				
				$email = $UC->checkEmail($info['user']['email']);
				if($email == false)
				{

					$array = array();
					$array['user'] = $info['user'];
					
					$user_id = $UC->saveUser($array);
			
					if(!is_numeric($user_id))
					{
						print json_encode(array('error'=>$user_id));
						break;
					}
					
					print json_encode(array('user_id'=>$user_id));
					
					breadcrumbclass::storeBcSession('edituser',$UC);
					
					if($new == true)
					{
						breadcrumbclass::clearLastBC();
					}
							
					
				}
				else 
				{
					print json_encode(array("error"=>1));
					
				}
			
				break;
			}
		}
		/*
		case "savegroup":
		{
			if($G = restoreClass('group'))
			{
				if(!isset($info['useringroup']))
				{
					
					$info['useringroup'] = array();
				}
				
				$gid = $G->saveGroup(array('group'=>$info['groups'],
											'usersingroup'=>$info['useringroup']));
				
				if(!is_numeric($gid))
				{
					if($gid == "duplicate group")
					{
						print json_encode(array('error'=>1));
					}
					else 
					{
						print json_encode(array('error'=>$gid));
					}
				}
				else 
				{
					print json_encode(array('gid'=>$gid));
				}
			}
			else 
			{
				print json_encode(array('error'=>'Invalid Group'));
			}
			break;	
		}
		case "dupemail":
		{
			$upid = false;
			if(isSetNum($info['upid']))
			{
				$upid = $info['upid'];
			}
			
			$U = new userclass(array('upid'=>$upid));
			
			$answer = $U->checkDupEmail($info['email']);
			$tmp['response'] = $answer;
			if(is_numeric($answer))
			{
				$U = new userclass(array('upid'=>$answer));
				$tmp['page'] = $U->showAdminUserEdit();
				
			}
			print json_encode($tmp); 
			
			//print json_encode(array('error'=>'Invalid User'));
			break;		
		} */
	}
}