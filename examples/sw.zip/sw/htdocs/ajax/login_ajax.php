<?php
$ajax_page="Y";
$publicpage = 1;
include_once("config/systemsetup.php");

if(isset($_GET['id']))
{
	$info = $_GET;
}
else 
{
	$info = $_POST;
}

if(isset($info['id']))
{
	switch($info['id'])
	{
		case "login":
		{
			$L = new loginclass();
			$response = $L->loginUser($info['login'],$info['password']);
			
			print json_encode(array('response'=>$response));
			break;
		}
		case "logout":
		{
			$L = new loginclass();
			$L->logOut();
			break;		
		}
	}
}