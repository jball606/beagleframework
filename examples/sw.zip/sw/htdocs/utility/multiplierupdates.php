<?php
$pagename = "Multiplier Updates";
include("php_top.php");

if(isSetNum($_POST['calc']))
{
	$errors = array();
	if(isPopArray($_POST['resultedit']['utility_multipliers']))
	{
		$UM = new utility_multipliers();
		foreach($_POST['resultedit']['utility_multipliers'] as $k => $i)
		{
			if(is_numeric($k))
			{
				$UM->update(array('utility_multiplier_id'=>$k),$i);	
				
			}
		}
		
	}
	
}

if(!$UC = breadcrumbclass::getLastBCSession('utilitymultiplierfullsearch'))
{
	$UC = new utility_multipliers_controller();
	

}

breadcrumbclass::showBcChain();
?>
<form method="post" action="<?=$_SERVER['PHP_SELF'];?>" >
<input type="hidden" name="calc" value="1"/>
<input type="submit" class="popupbutton" value="Update"/>
<h1><?=$pagename;?></h1>
<? if(isSetNum($_POST['calc']))
{ ?><ul class="erroralert" id="error"><li>Multipliers Updated</li></ul><? } 
else 
{ ?><ul class="error" id="error"></ul> <? }
?>

<br clear="all"/>
<script type="text/javascript" src="/js/beaglejs/beagleResults.js"></script>
<script type="text/javascript" src="/js/utility/multipliers.js"></script>

<script type="text/javascript">
<!--
var umultiplier = new multiplierclass();

var utilitymultiplierfullsearch = new beagleResults({resultdiv:'utilitymultiplierlist',search:'utilitymultiplierfullsearch'});

utilitymultiplierfullsearch.userFunction = function(field,utility_id) 
			{ 
			//	window.location.href="editutility.php?utility_id="+utility_id;
			};

//-->
</script>

<div id="utilitymultiplierlist">
<?=$UC->showResultsPage(array('lib'=>'utilitymultiplierfullsearch','orderby'=>array('utility_providers.name','lease_term','multiplier_type_id'),'orderdir'=>array(1,1,1)));?>
</div>
<br/>
<input type="submit" class="popupbutton" value="Update" />

</form>
<? 
breadcrumbclass::storeBcSession('utilitymultiplierfullsearch',$UC); 
include("php_bottom.php");
?>