<?php
$menulist = 4;
include_once("config/systemsetup.php");

$utility_id = false;
if(isSetNum($_GET['utility_id']))
{
	$utility_id = $_GET['utility_id'];
}

$U = new utilityclass(array('utility_id'=>$utility_id));

$row = $U->getutilityData('all');

if(getValue($row,'name') != false)
{
	$pagename = getValue($row,'name');
}
else 
{
	$pagename = "New utility";
}

include("php_top.php");
?>
<script type="text/javascript" src="/js/utility/utility.js"></script>
<script type="text/javascript" src="/js/beaglejs/beagleResults.js"></script>
<? 
breadcrumbclass::showBcChain();
?>

<form id="utilityadd">
<?=$U->showEditUtility();?>
</form>

<? 
$U->currentstate = 8;

breadcrumbclass::storeBCSession('editutility', $U);

include("php_bottom.php");
?>