<?php
include("config/systemsetup.php");
if(!$C =  breadcrumbclass::restoreBcSession('editutility'))
{ 
	?><ul class="erroralert"><li>Invalid Utility</ul><?
	exit;
}
?>

<form id="utilitytariffadd">
<div id="utilitypage_div">
<? 
echo $C->showAddTariffs();
?>
</div>
</form>
