<?php
include("config/systemsetup.php");
if(!$C =  breadcrumbclass::restoreBcSession('editutility'))
{ 
	?><ul class="erroralert"><li>Invalid Utility</ul><?
	exit;
}
?>

<?
$utility_id = false;
if(isSetNum($_GET['utility_id']))
{
	$utility_id = $_GET['utility_id'];
}
$G = new utilityclass(array('utility_id'=>$utility_id));
?>

<form id="utilitystateadd">
<div id="utilitypage_div">
<? 
echo $G->showUtilityStates();
?>
</div>
</form>
