<?php
include("config/systemsetup.php");

$G = new utility_multipliers_controller();
?>

<form id="utilitymultiplieradd">
<div id="utilitypage_div">
<? 
echo $G->showAddMultiplier();
?>
</div>
</form>
