<?php
include("config/systemsetup.php");
if(!$C =  breadcrumbclass::restoreBcSession('editutility'))
{ 
	?><ul class="erroralert"><li>Invalid Utility</ul><?
	exit;
}
?>


<form id="utilitymultiplieradd">
<div id="utilitypage_div">
<? 
echo $C->showAddMultiplier();
?>
</div>
</form>
