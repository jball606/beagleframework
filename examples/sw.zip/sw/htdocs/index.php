<?php
$accessparam['public'] = 1;
include("php_top.php");
if(is_object($user))
{
	header("location:/home.php");
	exit;
}

print("HELLO");


include("php_bottom.php");
?>