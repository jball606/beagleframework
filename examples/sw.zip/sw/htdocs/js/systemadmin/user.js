$.formValidateSettings({jump:true});

function userclass()
{
	
	this.verify = verify;
	
	function verify()
	{
		clearError('error');
		clearError('email_error','email_error_tr');
		
		
			if($.formValidate({list:'user_req_div'}))
			{
				if(emailCheck($("#email").val()))
				{
					var param = $("#useradd").serialize()+"&id=usersave";
					$.ajax({
							url:"/ajax/user_ajax.php",
							data:param,
							success:function(json)
							{
								
								if(isset(json))
								{
									if(isset(json.error))
									{
										if(isset(json.error))
										{
											if(json.error == 1)
											{	
												showError('Email Already In Use','email_error','email_error_tr');
												showError('Email Already In Use','error');
												window.scroll(0,0);
												timer.stopWait();
											}
											else
											{
												showError(json.error,'error');
												window.scroll(0,0);
												timer.stopWait();
											}
										}
									}
									else if(isset(json.user_id))
									{
										window.location.href="edituser.php?user_id="+json.user_id+"&add=1";
									}
								}
							}
					});
				}
				else
				{
					showError(badEmail,'email_error','email_error_tr');
					showError(badEmail,'error');
					window.scroll(0,0);
					timer.stopWait();
				}
			}
			else
			{
				showError('Please fill in all required fields','error');
			}
				
		
			
		
	}
}