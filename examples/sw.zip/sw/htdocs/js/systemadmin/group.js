$.formValidateSettings({jump:true});

function groupclass(obj)
{
	
	this.verify = verify;
	this.addGroupUser = addGroupUser;
	this.saveGroupUsers = saveGroupUsers;
	this.removeGroupUsers = removeGroupUsers;
	this.showTypeButton = showTypeButton;
	this.updateTypes = updateTypes;
	
	var group_id = "";
	var search = 'groupsearch';
	
	if(isset(obj['group_id']))
	{
		group_id = obj['group_id'];
		
	}
	
	function showTypeButton()
	{
		$("#typebutton").css('display','inline');
		
	}
	
	function updateTypes()
	{
		clearError('error');
		clearError('bottomerror');
		
		var aws = groupsearch.checkSelected();
		
		
		if(aws == false)
		{
			showError('No Users have been selected','error');
			showError('No Users have been selected','bottomerror');
		}
		else
		{
			var gm = confirm("Are you sure you want to update selected users in group?");
			if(gm == true)
			{
				var type = $("#groupusertype").val();
				if(type != '')
				{
					var data = "id=updateusertype&search="+search+"&usertype="+type;
					$.ajax({
							url:"/ajax/group_ajax.php",
							data:data,
							success:function(json)
							{
								timer.stopWait();
								if(isset(json))
								{
									if(isset(json.error))
									{
										showError(json.error,'error');
										showError(json.error,'bottomerror');
										return false;
									}
									else if(isset(json.group_id))
									{
										groupsearch.searchResult(0);
									}
									
								}
							}
						
					});
				}
				else
				{
					showError('Invalid Group User Type','bottomerror');
				}
				
			}
		}
		
	}
	
	function verify()
	{
		clearError('error');
		
		
			if($.formValidate({list:'group_req_div'}))
			{
				
				var param = $("#groupadd").serialize()+"&id=groupsave";
				$.ajax({
						url:"/ajax/group_ajax.php",
						data:param,
						success:function(json)
						{
								
							if(isset(json))
							{
								if(isset(json.error))
								{
									if(isset(json.error))
									{
										showError(json.error,'error');
										window.scroll(0,0);
										timer.stopWait();
						
									}
								}
								else if(isset(json.group_id))
								{
									window.location.href="editgroup.php?group_id="+json.group_id+"&add=1";
								}
							}
						}
					});
			}
			else
			{
				showError('Please fill in all required fields','error');
			}
				
		
			
		
	}
	
	function addGroupUser()
	{
		$.fancybox({
			autoScale:false,
			type:'ajax',
			padding:0,
			href:"/systemadmin/popups/groupusers.php?group_id="+group_id,
			onClosed:function()
			{
				groupsearch.searchResult(0);
			}
		});
	
		
	}
	
	function removeGroupUsers()
	{
		clearError('error');
		clearError('bottomerror');
		var aws = groupsearch.checkSelected();
		
		
		if(aws == false)
		{
			showError('No Users have been selected','error');
			showError('No Users have been selected','bottomerror');
		}
		else
		{
			var gm = confirm("Are you sure you want to remove selected users from group?");
			if(gm == true)
			{
				var data = "id=removegroupusers&search="+search;
				$.ajax({
						url:"/ajax/group_ajax.php",
						data:data,
						success:function(json)
						{
							timer.stopWait();
							if(isset(json))
							{
								if(isset(json.error))
								{
									showError(json.error,'error');
									showError(json.error,'bottomerror');
									return false;
								}
								else if(isset(json.group_id))
								{
									groupsearch.searchResult(0);
								}
								
							}
						}
					
				});
				
			}
		}
		
	}
	
	function saveGroupUsers()
	{
		clearError('groupuser_error');
		$.formValidateSettings({jump:false});
		
		$('#useringroup option').each(function(i) 
		{  
		   	$(this).attr("selected", "selected");  
		});  
		
		var data = $("#groupuseradd").serialize()+"&id=savegroupusers";
		$.ajax({
				url:"/ajax/group_ajax.php",
				data:data,
				beforeSend:function() { timer.startWait('group_div_block'); },
				success:function(json)
				{
					timer.stopWait('group_div_block');
					if(isset(json))
					{
						if(isset(json.error))
						{
							showError(json.error,'groupuser_error');
							return false;
						}
						else if(isset(json.group_id))
						{
							groupsearch.searchResult(0);
							$.fancybox.close();
						}
						
					}
				}
			
		});
	
	}
}