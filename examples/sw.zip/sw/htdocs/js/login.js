function beagleLogin(obj)
{
	
	var me = this;
	var blankBox = 'Please fill in your username and password';
	var invalidData = 'Invalid username or password';
	
	this.systemLogin = systemLogin;
	this.systemLogout = systemLogout;
	
	if(isset(obj))
	{
		if(isset(obj.blankBox))
		{
			blankBox = obj.blankBox;
		}
		if(isset(obj.invalidData))
		{
			invalidData = obj.invalidData;
		}
	}
	
	function systemLogin()
	{
		clearError('error');
		var l = $("#login").val();
		var p = $("#password").val();
		
		if(l == "" || p == "")
		{
			showError(blankBox,'error');
			return false;
		}
	
		var param = $("#loginform").serialize()+"&id=login";
		$.ajax({
				url:"/ajax/login_ajax.php",
				data:param,
				beforeSend:function() { timer.startWait('logdata'); },
				success:function(json)
				{
					if(json.response == 0)
					{
						showError(invalidData,'error');
					}
					else if(json.response == 1)
					{
						$("#loginform").attr('action',"/home.php");
						$("#loginform").submit();
					}
					
					
					timer.stopWait('logdata');
				}
		});
				
		
	}
	
	function systemLogout()
	{
		$.ajax({
				url:"/ajax/login_ajax.php",
				data:{id:'logout'},
				success:function(json)
				{
					window.location.href="/index.php";
				}
		});
		
	}
}