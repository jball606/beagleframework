// JavaScript Document
function htmlmaker()
{
	var me  = this;	
	var is_selected = Array();
	
	this.changeElement = changeElement;
	this.getBr = getBr;
	this.getDiv = getDiv;
	this.getInput = getInput;
	this.getLi = getLi;
	this.getLink = getLink;
	this.getImg = getImg;
	this.getSelect = getSelect;
	this.getSpan = getSpan;
	this.getTable = getTable;
	this.getTbody = getTbody;
	this.getTd = getTd;
	this.getTh = getTh;
	this.getTr = getTr;
	this.getUl = getUl;
	
	function changeElement(parent,obj)
	{
		if(obj == undefined)
		{
			return parent;
		}	
		
		parent = addFlair(parent,obj);
		return parent;
	}
	
	function getBr(obj)
	{
		var br = document.createElement('br');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
	}
	
	function getDiv(obj)
	{
		var br = document.createElement('div');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
	}
	
	function getInput(obj)
	{
		if(obj == undefined)
		{
			return false;
		}
		
		if(!isset(obj['type']))
		{
			return false;
		}
		
		var input = document.createElement('input');
		
		input = addFlair(input,obj);
		
		return input;
	}
	
	function getLi(obj)
	{
		var br = document.createElement('li');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
		
	}
	
	function getLink(obj)
	{
		
		
		var linc = document.createElement('a');
		
		if(!isset(obj) || !isset(obj['href']))
		{
			linc.setAttribute('href','#');
		}

		if(obj == undefined)
		{
			return linc;
		}
		
		linc = setAtt(linc,obj);	
		linc = styleObject(linc,obj);
		return linc;
	
		
	}
	
	function getImg(obj)
	{
		if(obj == undefined)
		{
			return false;
		}
		var img = document.createElement('img');
		
		img = addFlair(img,obj);
		
		return img;	
	}
	
	function getObject(obj,opgroup)
	{
				  
		if(!isset(obj))
		{
			return false;
		}
		
		var data = Array();
		for(var a = 0;a<obj.length;a++)
		{
			if(isset(obj[a]['value']))
			{
				var tmp = document.createElement('option');
				
				tmp.value = obj[a]['value'];
			//	tmp.setAttribute('selected',true);
				
				if(opgroup == true)
				{
					tmp.innerHTML = obj[a]['text'];
				}
				else
				{
					tmp.text = obj[a]['text'];
				}
				
				//tmp.selected = false;
				if(isset(obj[a]['selected']))
				{
					is_selected[is_selected.length] = obj[a]['value']; //tmp.selected = true;
				}
				
				data[data.length] = tmp;
				
			
			}
		}
	//	alert(data[0]['selected']+" DATA");
		return data;
	}
	
	function getOptGroup(obj)
	{
		var tmp = Array();
		for(var key in obj)
		{
			var gr = document.createElement('optgroup');
			if(isset(obj[key]['name']))
			{
				gr.label = obj[key]['name'];
			}
			
			var val = getObject(obj[key]['values'],true);
			
			
		
			for(var a = 0;a<val.length;a++)
			{
				gr.appendChild(val[a]);
			}
		
			tmp[tmp.length] = gr;
		}
		return tmp;
	}
	function getSelect(obj)
	{
		is_selected = Array();
		var br = document.createElement('select');
		
		if(obj == undefined)
		{
			return br;
		}

		if(isset(obj['multiple']))
		{
			br.multiple = true;
			obj['multiple'] = null;
		}
		if(isset(obj['values']))
		{
			
			var val = getObject(obj['values']);
			
			for(var a = 0;a<val.length;a++)
			{
				try
				{
					br.add(val[a],null); //Standard
				}
				catch(ex)
				{
					br.add(val[a]); //IE
				}
			}
		}
		if(isset(obj['optgroup']))
		{
			var val = getOptGroup(obj['optgroup']);
			for(var a = 0;a<val.length;a++)
			{
				br.appendChild(val[a]);
			}
		}

		selector(br,is_selected);
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
		
	}
	function getSpan(obj)
	{
		var br = document.createElement('span');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
	}
	
	function getTable(obj)
	{
		var br = document.createElement('table');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
		
	}
	
	function getTbody(obj)
	{
		var br = document.createElement('tbody');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
	}
	
	function getTd(obj)
	{
		var br = document.createElement('td');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
			
	}
	
	function getTh(obj)
	{
		var br = document.createElement('th');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
		
	}
	
	function getTr(obj)
	{
		var br = document.createElement('tr');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
		
	}

	function getUl(obj)
	{
		var br = document.createElement('ul');
		
		if(obj == undefined)
		{
			return br;
		}

		br = addFlair(br,obj);
		
		return br;
		
	}
	
	function addFlair(parent,obj)
	{
		
		parent = setAtt(parent,obj);
		parent = styleObject(parent,obj);
		
		return parent;	
	}
	
	function setAtt(parent,obj)
	{
		for(var key in obj)
		{
			if(key != "style" && key != 'values')
			{
				if(key == 'className')
				{
					var tmp = 'class';
					//IE7/6 Fix
					parent.setAttribute(tmp,obj[key]);
					parent.setAttribute(key,obj[key]);
				}
				else
				{
					var tmp = key;
					parent.setAttribute(tmp,obj[key]);
				}
				
				//parent.setAttribute(tmp,obj[key]);
			}
		}
		return parent;
	}
	
	function styleObject(parent,obj)
	{
		if(isset(obj['style']))
		{
			var sty = obj['style'];
			for(var key in sty)
			{
				
				var bob = 'parent.style.'+key+' = "'+sty[key]+'";';
				eval(bob);	
				
				//IE Fix
				if(key == "styleFloat")
				{
					var bob = 'parent.style.cssFloat = "'+sty[key]+'";';
					eval(bob);
				}
			}	
		}
		return parent;
	}
	
}