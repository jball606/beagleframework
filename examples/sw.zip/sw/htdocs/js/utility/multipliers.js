function multiplierclass(obj)
{

	var search = 'utilitymultiplierfullsearch';
	
	this.addMultiplier = addMultiplier;
	this.saveUtilityMultipliers = saveUtilityMultipliers;
	this.removeMultipliers = removeMultipliers;
	
	function addMultiplier()
	{
		var aw = confirm("If you add a new record, any unsaved changes will be lost.  Do you want to continue ot add a new multiplier?");
		
		if(aw == true)
		{
			$.fancybox({
				autoScale:false,
				type:'ajax',
				padding:0,
				href:"/utility/popups/addfullmultiplier.php",
				onClosed:function()
				{
					utilitymultiplierfullsearch.searchResult(0);
					showError('Record Added','error');
					window.scrollTo(0,0);	
				}
			});
		}
		
	}
	
	function removeMultipliers()
	{
		clearError('error');
		clearError('utilitymultiplierbottomerror');
		var aws = utilitymultiplierfullsearch.checkSelected();
		
		
		if(aws == false)
		{
			showError('No multipliers have been selected','error');
			showError('No multipliers have been selected','utilitymultiplierbottomerror');
		}
		else
		{
			var gm = confirm("Are you sure you want to remove selected multipliers?");
			if(gm == true)
			{
				var data = "id=removefullmultiplier&search="+search;
				$.ajax({
						url:"/ajax/utility_ajax.php",
						data:data,
						success:function(json)
						{
							timer.stopWait();
							if(isset(json))
							{
								if(isset(json.error))
								{
									showError(json.error,'error');
									showError(json.error,'utilitymultiplierbottomerror');
									return false;
								}
								else if(isset(json.utility_multiplier_id))
								{
									utilitymultiplierfullsearch.searchResult(0);
									showError('Records Removed','error');
									window.scrollTo(0,0);	
								}
								
							}
						}
					
				});
				
			}
		}
		
		
		
	}
	
	function saveUtilityMultipliers()
	{
		clearError('utilitymultiplier_error');
		$.formValidateSettings({jump:false});
		
		if($.formValidate({list:'mult_req'}))
		{
			var data = $("#utilitymultiplieradd").serialize()+"&id=addfullutilitymultiplier";
			$.ajax({
					url:"/ajax/utility_ajax.php",
					data:data,
					beforeSend:function() { timer.startWait('utilitymultiplier_div_block'); },
					success:function(json)
					{
						timer.stopWait('utilitymultiplier_div_block');
						if(isset(json))
						{
							if(isset(json.error))
							{
								showError(json.error,'utilitymultiplier_error');
								return false;
							}
							else if(isset(json.utility_multiplier_id))
							{
								utilitymultiplierfullsearch.searchResult(0);
								$.fancybox.close();
							}
							
						}
					}
				
			});
			
		}
		else
		{
			showError('Please fill in required fields','utilitymultiplier_error');
		}
		
	}
	
}
