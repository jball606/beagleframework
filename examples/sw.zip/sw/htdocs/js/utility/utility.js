function utilityclass(obj)
{
	var utility_id = "";
	var search = 'utilitysearch';
	
	this.addUtilityState = addUtilityState;
	this.saveUtilityStates = saveUtilityStates;
	this.removeUtilityStates = removeUtilityStates;
	this.showStateData = showStateData;
	this.verify = verify;
	this.addMultiplier = addMultiplier;
	this.saveUtilityMultipliers = saveUtilityMultipliers;
	this.removeUtilityMultipliers = removeUtilityMultipliers;
	this.addTariffs = addTariffs;
	this.attachTariffs = attachTariffs;
	this.saveAttachedTariffs = saveAttachedTariffs;
	
	if(isset(obj['utility_id']))
	{
		utility_id = obj['utility_id'];
		
	}
	
	
	function verify()
	{
		clearError('error');
		
		if($.formValidate({list:'utility_req_div'}))
		{
			var param = $("#utilityadd").serialize()+"&id=utilitysave";
					
			$.ajax({
					url:"/ajax/utility_ajax.php",
					data:param,
					success:function(json)
					{
						timer.stopWait();
						if(isset(json))
						{
							if(isset(json.error))
							{
								if(isset(json.error))
								{
									showError(json.error,'error');
									window.scroll(0,0);
									timer.stopWait();
								}
							}
						}
						else if(isset(json.utility_id))
						{
							window.location.href="editutilityr.php?utility_id="+json.utility_id+"&add=1";
						}
					
					}
					});
			}
			else
			{
				showError('Please fill in all required fields','error');
			}
	}
	
	function saveAttachedTariffs()
	{
		clearError('utilitymultiplier_error');
		$.formValidateSettings({jump:false});
		
		if($.formValidate({list:'mult_req'}))
		{
			var data = $("#utilitymultiplieradd").serialize()+"&id=addutilitymultiplier";
			$.ajax({
					url:"/ajax/utility_ajax.php",
					data:data,
					beforeSend:function() { timer.startWait('utilitymultiplier_div_block'); },
					success:function(json)
					{
						timer.stopWait('utilitymultiplier_div_block');
						if(isset(json))
						{
							if(isset(json.error))
							{
								showError(json.error,'utilitymultiplier_error');
								return false;
							}
							else if(isset(json.utility_multiplier_id))
							{
								utilitymultipliersearch.searchResult(0);
								$.fancybox.close();
							}
							
						}
					}
				
			});
			
		}
		else
		{
				showError('Please fill in required fields','utilitymultiplier_error');
		}
		
		
	}
	
	function addMultiplier()
	{
		$.fancybox({
			autoScale:false,
			type:'ajax',
			padding:0,
			href:"/utility/popups/addmultipliers.php",
			onClosed:function()
			{
				utilitymultipliersearch.searchResult(0);
			}
		});
		
		
	}
	
	function addTariffs()
	{
		$.fancybox({
			autoScale:false,
			type:'ajax',
			padding:0,
			href:"/utility/popups/addutilitytariffs.php",
			onClosed:function()
			{
				utilitymultipliersearch.searchResult(0);
			}
		});
		
	}
	
	function attachTariffs()
	{
		$.fancybox({
			autoScale:false,
			type:'ajax',
			padding:0,
			href:"/utility/popups/attachutilitytariffs.php",
			onClosed:function()
			{
				utilitymultipliersearch.searchResult(0);
			}
		});
		
	}
	
	function removeUtilityMultipliers()
	{
		clearError('error');
		clearError('utilitymultiplierbottomerror');
		var aws = utilitymultipliersearch.checkSelected();
		
		
		if(aws == false)
		{
			showError('No Multipliers have been selected','error');
			showError('No Multipliers have been selected','utilitymultiplierbottomerror');
		}
		else
		{
			var gm = confirm("Are you sure you want to remove selected multipliers from utility?");
			if(gm == true)
			{
				var data = "id=removegivenutilitymultipliers&search=utilitymultipliersearch";
				$.ajax({
						url:"/ajax/utility_ajax.php",
						data:data,
						success:function(json)
						{
							timer.stopWait();
							if(isset(json))
							{
								if(isset(json.error))
								{
									showError(json.error,'error');
									showError(json.error,'utilitymultiplierbottomerror');
									return false;
								}
								else if(isset(json.utility_id))
								{
									utilitymultipliersearch.searchResult(0);
								}
								
							}
						}
					
				});
				
			}
		}
		
		
	}
	
	function saveUtilityMultipliers()
	{
		clearError('utilitymultiplier_error');
		$.formValidateSettings({jump:false});
		
		if($.formValidate({list:'mult_req'}))
		{
			var data = $("#utilitymultiplieradd").serialize()+"&id=addutilitymultiplier";
			$.ajax({
					url:"/ajax/utility_ajax.php",
					data:data,
					beforeSend:function() { timer.startWait('utilitymultiplier_div_block'); },
					success:function(json)
					{
						timer.stopWait('utilitymultiplier_div_block');
						if(isset(json))
						{
							if(isset(json.error))
							{
								showError(json.error,'utilitymultiplier_error');
								return false;
							}
							else if(isset(json.utility_multiplier_id))
							{
								utilitymultipliersearch.searchResult(0);
								$.fancybox.close();
							}
							
						}
					}
				
			});
			
		}
		else
		{
				showError('Please fill in required fields','utilitymultiplier_error');
		}
	}
	
	function addUtilityState()
	{
		$.fancybox({
			autoScale:false,
			type:'ajax',
			padding:0,
			href:"/utility/popups/utilitystates.php?utility_id="+utility_id,
			onClosed:function()
			{
				utilitystatesearch.searchResult(0);
			}
		});
		
		
	}
	
	function removeUtilityStates()
	{
		clearError('error');
		clearError('utilitystatebottomerror');
		var aws = utilitystatesearch.checkSelected();
		
		
		if(aws == false)
		{
			showError('No States have been selected','error');
			showError('No States have been selected','utilitystatebottomerror');
		}
		else
		{
			var gm = confirm("Are you sure you want to remove selected states from utility?");
			if(gm == true)
			{
				var data = "id=removeutilitystates&search=utilitystatesearch";
				$.ajax({
						url:"/ajax/utility_ajax.php",
						data:data,
						success:function(json)
						{
							timer.stopWait();
							if(isset(json))
							{
								if(isset(json.error))
								{
									showError(json.error,'error');
									showError(json.error,'utilitystatebottomerror');
									return false;
								}
								else if(isset(json.utility_id))
								{
									utilitystatesearch.searchResult(0);
								}
								
							}
						}
					
				});
				
			}
		}
		
		
	}
	
	function saveUtilityStates()
	{
		clearError('utilitystates_error');
		$.formValidateSettings({jump:false});
		
		$('#stateinutility option').each(function(i) 
		{  
		   	$(this).attr("selected", "selected");  
		});  
		
		var data = $("#utilitystateadd").serialize()+"&id=saveutilitystates";
		$.ajax({
				url:"/ajax/utility_ajax.php",
				data:data,
				beforeSend:function() { timer.startWait('utilitystates_div_block'); },
				success:function(json)
				{
					timer.stopWait('utilitystates_div_block');
					if(isset(json))
					{
						if(isset(json.error))
						{
							showError(json.error,'utilitystates_error');
							return false;
						}
						else if(isset(json.utility_id))
						{
							utilitystatesearch.searchResult(0);
							$.fancybox.close();
						}
						
					}
				}
			
		});
		
		
	}

	function showStateData(utility_state_id)
	{
		var data = "id=getutilitystatedata&utility_state_id="+utility_state_id;
		$.ajax({
				url:"/ajax/utility_ajax.php",
				data:data,
				beforeSend:function() { },
				success:function(json)
				{
					$("#statedata").html(json.html);
					
				}
			
		});
		
		
	}


}