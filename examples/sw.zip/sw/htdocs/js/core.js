function isset(obj)
{
	if(obj != undefined)
	{
		return true;
	}
	else
	{
		return false;
	}
		
}


function selectAccessList()
{
	$('#accessusers option').each(function(i) 
	{  
	   	$(this).attr("selected", "selected");  
	});  
		
	$('#accessgroups option').each(function(i) 
	{  
	   	$(this).attr("selected", "selected");  
	});
			
	
}

function removeChildren(main,wmain)
{
	if(isset(main))
	{
		var child = main.childNodes;
		if(isset(child))
		{
			for(var a = child.length-1;a>= 0; a--)
			{
				if(child[a].childNodes.length>0)
				{
					removeChildren(child[a]);
	
				}
				main.removeChild(child[a]); 
				
			}
			if(wmain == true)
			{
				var parent = main.parentNode;
				parent.removeChild(main);
			}
		}
	}
}

function addcal(form,format)
{
	if(format == undefined || format == "")
	{
		format = "mm/dd/yy";
	}
	$(function() 
		{ 
			$("#"+form).datepicker({dateFormat: format, constrainInput:false, showOn: 'button', buttonImage: '/img/icons/calendar.png', buttonImageOnly: true, changeMonth: true, changeYear: true});
		}); 
	
}

function emailCheck(email)
{
	if(email == undefined || email == "")
	{
		return true;		
	}
	var reg = new RegExp(/^([A-Za-z0-9_\-.!#$%^&*+//=?'{|}~]*@[A-Za-z0-9_\-]([A-Za-z0-9_\-]*[A-Za-z0-9_\-])?(\.[A-Za-z0-9_\-]([A-Za-z0-9_\-]*[A-Za-z0-9_\-])?)+)/);
	var awn = reg.test(email);

	if(awn == true)
	{
		var tp = email.split("@");
		if(tp.length > 2)
		{
			return false;
		}
		
	}
	return awn;
	
}

function classSwap(id,classa,classb)
{
	if(document.getElementById(id).className == classa)
	{
		document.getElementById(id).className = classb;
	}
	else
	{
		document.getElementById(id).className = classa;
	}
	
}

function obj_merge(ob1,ob2)
{
	if(isset(ob1) && isset(ob2))
	{
		var no = {};
		$.extend(no,ob1,ob2);
		return no;
	}
	return false;
}

function clearError(id,subid)
{

	if(id != undefined && id != "")
	{
		removeChildren(document.getElementById(id));
		$("#"+id).css('display','none');
	}
	
	if(subid != undefined && subid != "")
	{
		$("#"+subid).css('display','none');
	}
	
}

function showError(elist,id,subid)
{
	if(elist != "")
	{
		var list = Array();
		
		if(is_Array(elist))
		{
			var x =0;
			for(var a = 0;a<elist.length;a++)
			{
				if(elist[a] != "")
				{
					list[x] = elist[a];
					x++;
				}
			}
		}
		else
		{
			list[0] = elist;
		}
		
		if(id != undefined && id != "")
		{
			if(document.getElementById(id))
			{	
				var obj = document.getElementById(id);
				for(var a =0;a<list.length;a++)
				{
					var er = document.createElement('li');
					er.innerHTML = list[a];
					obj.appendChild(er);
				}
				$("#"+id).css('display','block');
			}
		}
		
		
		if(subid != undefined && subid != "")
		{
			$("#"+subid).css('display','table-row');
		}
	}
}

function is_Array(obj)
{
	if (obj.constructor.toString().indexOf("Array") == -1)
	{
		return false;
	}
	else
	{
		return true;
	}
}

function trim(junk) 
{ 
	if(junk != undefined && junk != "")
	{
		junk = junk.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
		junk = junk.replace(/^\u00A0/,'').replace(/\u00A0/,'');
		return junk;
	}
	else
	{
		return "";
	}
}

function selected(op)
{
	var sel = "";
	for (i = 0 ; i < op.length ; ++i) 
		{ 
			if (op.options[i].selected) 
				{ sel += op.options[i].value+","; }
		}
	sel = sel.substr(0,sel.length-1);
	return sel;
}

function selector(op,value)
{
	if(value == undefined)
	{
		return false;
	}
	
	var tmp = Array();
	if(!is_Array(value))
	{
		tmp[0] = value;
	}
	else
	{
		tmp = value;
	}
	for (i = 0 ; i < op.length ; ++i) 
	{ 
		op.options[i].selected = false;
	}
	
	for (i = 0 ; i < op.length ; ++i) 
	{ 	
		for(var b=0;b<tmp.length;b++)
		{
			if (op.options[i].value == tmp[b]) 
			{ 
				op.options[i].selected = true;
			}
		}
	}
}

function addSelectOption(op,id,value)
{
	if(isset(id) && isset(value))
	{
		if(op)
		{
			op.options[op.options.length] = new Option(value,id);
		}
	}
}

function clearSelect(op)
{
	if(op)
	{
		var x = op.length;
		
		for(a = x; a>=0;a--)
		{
			op.remove(a);
		}
		
	}
}

function radioselect(op)
{ 
	if(op != undefined)
	{
		var x = op.length;
		if(isNaN(x))
		{
			if(op.checked == true)
			{
				return op.value;
			}
		}
		for(var i = 0;i<x;i++)
		{
			if(op[i].checked == true)
			{ 
				return op[i].value; 
			}
		}
		return '';
	}
}

function toggle_visibility(id,hset)
{
	var e = document.getElementById(id);
	if(e)
	{
		if((e.style.display == '' && hset != "show") || hset == "none")
		{	
			e.style.display = 'none'; 
		}
		else 
		{
			e.style.display = ''; 
		}
	}
	return false;
}

function onEnter(e,func,actionkey)
{
	if(actionkey == undefined)
	{
		actionkey = 13; 
	}
	var key;
	if(e.which == undefined)
	{ 
		key = window.event.keyCode; 
	}
	else
	{
		key = e.which; 
	}
	
	actionkey();
	/*
	if(key==actionkey)
	{
		eval(func+"();"); 
	} */
}

function midscreen(returnwhat)
{
	var screenW = screen.width;
	var screenH = screen.height;
	
	var scrn = new Array;
	scrn[0] = screenW/2;
	scrn[1] = screenH/2;
	if(returnwhat.toUpperCase == "H")
		{ return scrn[1]; }
	else if(returnwhat.toUpperCase() == "W")
		{ return scrn[0]; }
	else
		{ return scrn; } 
		
}

function selected(op)
{
	var sel = "";
	for (i = 0 ; i < op.length ; ++i) 
		{ 
			if (op.options[i].selected) 
				{ sel += op.options[i].value+","; }
		}
	sel = sel.substr(0,sel.length-1);
	return sel;
}

function checkAllRows(formName, chk)
{
  var count = document.forms[formName].elements.length;

  for (var i = 0; i < count; i++) {
    document.forms[formName].elements[i].checked = chk;
  }
}

function optionGroupSet(sel,obj)
{
	
	if(document.getElementById(sel))
	{
		$("#"+sel).empty();
		for(var key in obj)
		{
			if(!isNaN(key))
			{
				var bob = singleOptionSet(obj[key]);
				var op = $("#"+sel).attr('options');
				op[op.length] = bob;
				//$("#"+sel).append(singleOptionSet(obj[key]));
			}
			else
			{
				
				var opt = $('<optgroup />', 
                    	{
							label: key
							
			            });
			
				for(var keys in obj[key])
				{
					
					var option = singleOptionSet(obj[key][keys]);
					opt.append(option);
				}
				
				$("#"+sel).append(opt);
			}
		}
	}
				
}

function singleOptionSet(obj)
{
	if(isset(obj['value']) && isset(obj['id']))
	{
		if(isset(obj['selected']))
		{
			return new Option(obj['value'],obj['id'],true,true);
		}
		else
		{
		
			return new Option(obj['value'],obj['id']);
		}
		
	}
	
}

function optionSet(sel,obj)
{
	if(document.getElementById(sel))
	{
		$("#"+sel).empty();	
		for(var key in obj)
		{
			if(!isNaN(key))
			{
				var bob = singleOptionSet(obj[key]);
				var op = $("#"+sel).attr('options');
				op[op.length] = bob;
			}
		}
	}
}

function serializeRow(parent)
{
	var par = parent;
	var slist="";
	var array = Array();
	var tmp = "";
	for(var a=0;a<par.childNodes.length;a++)
	{
		if(par.childNodes[a].childNodes.length > 0)
		{
			
			if(par.childNodes[a].type == undefined || !par.childNodes[a].type == "select-one")
			{
				array[array.length] = serializeRow(par.childNodes[a]);
				
				
			}
			else
			{
				if(par.childNodes[a].id != "")
				{
					array[array.length] = $('#'+par.childNodes[a].id).serialize();
				}
			}
		}
		else
		{
			tmp = "";
			
			switch(par.childNodes[a].type)
			{
				case "text":
				{
					tmp = $("#"+par.childNodes[a].id).serialize();
					if(tmp != "")
					{
						array[array.length] = tmp;
						tmp = "";
					}
					break;
				}
				case "hidden":
				{
					tmp = $("#"+par.childNodes[a].id).serialize();
					if(tmp != "")
					{
						array[array.length] = tmp;
						tmp = "";
					}
					break;
					
				}
				case "checkbox":
				{
					if(par.childNodes[a].checked == true)
					{
						tmp = $("#"+par.childNodes[a].id).serialize();
						
						if(tmp != "" && tmp.indexOf('=')>-1)
						{
							array[array.length] = tmp;
							tmp = "";
						}
					}
					break;
				}
				default:
				{
					
				}
			}
		}
	}
	
	if(array.length >0)
	{
		slist = array[0];
		for(a=1;a<array.length;a++)
		{
			slist = slist+"&"+array[a];
		}
	}
	
	return slist;	
}

function openFloatResize()
{
	var fullsize = getClientSize('H');
	var top = $("#fancybox-wrap").css('top');
	var current = $("#fancybox-wrap").css("height");
	
	if(parseInt(current) >500)
	{
		if(parseInt(current) > (fullsize - (parseInt(top)+20)))
		{
			$("fancybox-wrap").css('height',(fullsize-parseInt(top)-20)+"px");
			$("#fancybox-content").css("overflow-y","scroll");
			$("#fancybox-content").css("height",fullsize-parseInt(top)-40+"px");
			
		}
		else
		{
			$("#fancybox-content").css("overflow","none");
		}
	}
}

function resizeFloatDiv(size)
{
	var fullsize = getClientSize('H');
	var top = $("#fancybox-wrap").css('top');
	var current = $("#fancybox-wrap").css("height");
	
	if(parseInt(current) > (fullsize - (parseInt(top)+20)))
	{
		$("#fancybox-content").css("overflow-y","scroll");
		$("#fancybox-content").css("height",fullsize-parseInt(top)-40+"px");
		
	
	}
	
}

function getClientSize(what) 
{
	var myWidth = 0, myHeight = 0;
	 
	if( typeof( window.innerWidth ) == 'number' ) 
	{
		//Non-IE
		myWidth = window.innerWidth;
		myHeight = window.innerHeight;
	}
	else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) 
	{
		//IE 6+ in 'standards compliant mode'
		myWidth = document.documentElement.clientWidth;
		myHeight = document.documentElement.clientHeight;
	} 
	else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) 
	{
		//IE 4 compatible
		myWidth = document.body.clientWidth;
		myHeight = document.body.clientHeight;
	}
	
	if(what == 'H')
	{ 
		return myHeight;
	}
	else
	{
		return myWidth;
	}
}

function reAltRow(parent, rowname)
{
	if(parent)
	{
	
		var x = 0;
		var elm = parent.childNodes;

		for(var a = 0;a<elm.length;a++)
		{
			if(elm[a].id != undefined)
			{
				if(elm[a].id.indexOf(rowname)>-1)
				{
					x++;
					if((x % 2) ==0)
					{
						elm[a].className = "dblock_altrow";
					}
					else
					{
						elm[a].className = "";
					}
				}
			}
		
			if(elm[a].childNodes.length>0)
			{
				reAltRow(elm[a],rowname);	
			}
			
		}
	}
}

function addRemoveSelect(addid,removeid)
{
	$('#'+removeid+' option:selected').each( function() 
		{
		   	$('#'+addid).append("<option value='"+$(this).val()+"'>"+$(this).text()+"</option>");
           	$(this).remove();
		});
}

function addScript(file)
{ 
	document.write('<script language = "javascript" type="text/javascript" src = "'+file+'"></script>'+"\n"); 
}