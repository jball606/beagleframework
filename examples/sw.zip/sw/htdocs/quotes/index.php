<?php
$pagename = "Quote List";
$utilitylist = 4;
include("php_top.php");

if(!$UC = breadcrumbclass::getLastBCSession('utilitysearch'))
{
	//$UC = new utilities_controller();
	$UC = new quotes_controller();

}

breadcrumbclass::showBcChain();
?>
<h1><?=$pagename;?></h1>

<ul class="image">
	<li class="plus link" style="width:100px;"><a href="editutility.php">Add New Quote</a></li>

</ul>
<script type="text/javascript" src="/js/beaglejs/beagleResults.js"></script>
<script type="text/javascript">
<!--
var utilitysearch = new beagleResults({resultdiv:'utilitylist',search:'utilitysearch'});

utilitysearch.userFunction = function(field,utility_id) 
			{ 
				window.location.href="editutility.php?utility_id="+utility_id;
			};

//-->
</script>

<div id="utilitylist">
<?=$UC->showResultsPage(array('lib'=>'utilitysearch','limit'=>10));?>
</div>

<? 
breadcrumbclass::storeBcSession('utilitysearch',$UC); 
include("php_bottom.php");
?>